import {BrowserModule} from '@angular/platform-browser';
import {Compiler, NgModule} from '@angular/core';
import {NgZorroAntdModule, NZ_I18N, NZ_MESSAGE_CONFIG, NZ_NOTIFICATION_CONFIG, zh_CN} from 'ng-zorro-antd';
import zh from '@angular/common/locales/zh';
import {NgxEchartsModule} from 'ngx-echarts'
/** 配置 angular i18n **/
import {registerLocaleData} from '@angular/common';
import {AppComponent} from './app.component';
import {appRoutingModule} from './app.routing.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {HttpClientModule} from '@angular/common/http';
import {ServiceWorkerModule} from '@angular/service-worker';
import {environment} from '../environments/environment';

registerLocaleData(zh);

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    NgxEchartsModule,
    BrowserModule,
    BrowserAnimationsModule,
    appRoutingModule,
    /** 导入 ng-zorro-antd 模块 **/
    NgZorroAntdModule,
    HttpClientModule,
    ServiceWorkerModule.register('/ngsw-worker.js', {enabled: environment.production})
  ],
  /** 配置 ng-zorro-antd 国际化 **/
  providers: [
    {provide: NZ_I18N, useValue: zh_CN},
    {provide: NZ_MESSAGE_CONFIG, useValue: {nzMaxStack: 1}},
    {provide: NZ_NOTIFICATION_CONFIG, useValue: {nzMaxStack: 1}}
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
