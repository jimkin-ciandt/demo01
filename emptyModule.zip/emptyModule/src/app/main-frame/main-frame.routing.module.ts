import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {MainFrameComponent} from './main-frame-component/main-frame.component';
import {DefaultPageComponent} from '../default/default-page/default-page.component';
import {BookkeepingComponent} from '../default/bookkeeping/bookkeeping.component';
import {SumbyuserAndCodeComponent} from '../default/sumbyuser-and-code/sumbyuser-and-code.component';
import {SumTypebyTypeComponent} from '../default/sum-typeby-type/sum-typeby-type.component';

const mainFrameRoutes: Routes = [{
  path: '',
  children: [
    {
      path: '', component: MainFrameComponent, children: [
        {
          path: 'default', loadChildren: '../default/default.module#DefaultModule',data:{title:'首页'}
        }
      ]
    }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(mainFrameRoutes)],
  exports: [RouterModule]
})
export class MainFrameRoutingModule {

}
