/**
 *宁波琢华软件科技有限公司
 *create by 兰志辉
 *-----主框架服务层----
 */
import {Injectable} from '@angular/core';
import {AppServiceService} from '../app.service.service';
import {Observable} from 'rxjs';

@Injectable()
export class MainFrameService {
  constructor(private gService: AppServiceService) {
  }

  //注销接口
  logout() {
    return this.gService.postApi('/api/SysUser/LogOut', null);
  }

  //获取顶部导航菜单接口
  getMenuBarList(params): Observable<{ data: menuBarList[] }> {
    return this.gService.postApi('/api/SysMenu/GetMenuAndButtonByParentID', params);
  }

  //获取侧边导航栏接口
  getSlideBarList(params): Observable<{ data: menuBarList[] }> {
    return this.gService.postApi('/api/SysMenu/GetMenuAndButtonByUrl', params);
  }

  //获取用户名
  getEmpName() {
    return this.gService.getApi({}, '');
  }
}

export interface menuBarList {
  'id'?: string
  'parent_id'?: string
  'path'?: string
  'name'?: string
  'icon'?: string
  'rights'?: {
    is_flag?: number
    page_code?: string
  }
  'system_flag'?: string

  'son'?: menuBarList[]
}
