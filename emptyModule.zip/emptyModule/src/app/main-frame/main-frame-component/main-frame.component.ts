import {AfterViewInit, Component, ElementRef, HostListener, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {MainFrameService, menuBarList} from '../main-frame.service';
import {SlideBarComponent} from '../slide-bar/slide-bar.component';
import {NavigationEnd, NavigationStart, RouteConfigLoadStart, Router} from '@angular/router';
import {filter} from 'rxjs/operators';

@Component({
  selector: 'app-main-frame',
  templateUrl: './main-frame.component.html',
  styleUrls: ['./main-frame.component.css'],

})
export class MainFrameComponent implements OnInit, AfterViewInit, OnDestroy {

  constructor(private router: Router, private service: MainFrameService, private element: ElementRef) {
  }

  @ViewChild('mainWrap') mainWrap: ElementRef;
  @ViewChild(SlideBarComponent) slideBar: SlideBarComponent;

  ngOnInit() {
    this.watchRouterNavi();//监听路由导航
  }

  //页面初始化完成后监听滚动
  ngAfterViewInit() {
    this.scrollWatcher();
  }

  //页面销毁移除监听
  ngOnDestroy() {
    this.destoryListener();
  }

  //收起导航
  toggleParms: boolean = false;

  //左侧导航收起
  mouseIn() {
    this.slideBar.menuToggle = false;
    this.slideBar.isDetailShow = false;
  }

  //向上滚动移除参数
  isScrollOver: boolean = false;
  scrollHandler = (e: Event) => {
    let dom = <HTMLElement>e.target;
    this.slideBar.scrollOver = this.isScrollOver = dom.scrollTop > 20;
  };

  scrollWatcher() {
    let element = <HTMLElement>this.mainWrap.nativeElement;
    element.addEventListener('scroll', this.scrollHandler);
  }

  //销毁监听
  destoryListener() {
    let element = <HTMLElement>this.mainWrap.nativeElement;
    element.removeEventListener('scroll', this.scrollHandler);
  }

  scrollElement() {
    return document.getElementById('mainFrameWrap');
  };

  //滚动条显示控制字段
  loadingWrap: boolean = false;
  //滚动条值
  progressValue: number = 10;
  //加载器id
  requestID: number = 0;

  //进度条加载器
  intervalProgress() {
    let handler = () => {
      this.progressValue += 5;
      if (this.progressValue < 100) {
        requestAnimationFrame(handler);
      }
    };
    this.requestID = requestAnimationFrame(handler);
  };

  //监听导航控制滚动条
  watchRouterNavi() {
    this.router.events.pipe(filter((events) => {
      return events instanceof RouteConfigLoadStart;
    })).subscribe(res => {
      this.loadingWrap = true;
      this.intervalProgress();
    });
    this.router.events.pipe(filter((events) => {
      return events instanceof NavigationEnd;
    })).subscribe(res => {
      this.loadingWrap = false;
      this.progressValue = 10;
      if (this.requestID) {
        window.cancelAnimationFrame(this.requestID);
      }
    });
  }
}
