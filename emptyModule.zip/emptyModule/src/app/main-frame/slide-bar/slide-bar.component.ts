import {Component, Input, OnInit} from '@angular/core';
import {MainFrameService, menuBarList} from '../main-frame.service';
import {routeAnimationLeftIn} from '../../app.animations';
import {ActivatedRoute, NavigationEnd, Router} from '@angular/router';
import {filter} from 'rxjs/operators';

@Component({
  selector: 'app-slide-bar',
  templateUrl: './slide-bar.component.html',
  styleUrls: ['./slide-bar.component.css'],
  animations: [routeAnimationLeftIn]
})
export class SlideBarComponent implements OnInit {

  constructor(private service: MainFrameService, private router: Router, private activeRoute: ActivatedRoute) {
  }

  ngOnInit() {

  }

  /**
   * 主菜单悬浮
   * */
  menuToggle = false;

  //鼠标进入
  menuMouseIn(e) {
    this.menuToggle = true;
  }

  /**
   * 标记已选模块
   * */
    //当前模块url
  currentUrl: string = '';

  //当前模块
  watchRouter() {
    this.currentUrl = this.router.url;
    this.router.events.pipe(filter((events) => {
      return events instanceof NavigationEnd;
    })).subscribe((event: NavigationEnd) => {
      this.checkCurrentMenu();
    });
  }

  //检查菜单
  checkCurrentMenu() {
    this.currentUrl = this.router.url;
    for (let i = 0; i < this.sourceMenuItem.length; i++) {
      if (this.currentUrl.indexOf(this.sourceMenuItem[i].path) !== -1) {
        this.selectedMenuIndex = i;
        break;
      }
    }
  }

  //当前选择的模块索引
  selectedMenuIndex: number = -1;
  /**
   * 获取主菜单
   * */
    //菜单源数据
  sourceMenuItem: menuBarList[];

  //显示详情菜单
  isDetailShow: boolean = false;

  //点击详细菜单
  menuSelected(event, item: menuBarList, index) {
    this.selectedMenuIndex = index;
    this.isDetailShow = true;
    let sliderBarList = JSON.parse(sessionStorage.getItem('sliderBarList'));
    if (sliderBarList&&sliderBarList.hasOwnProperty(item.path)) {
      this.slideBarList = sliderBarList[item.path];
    }
    else {
      this.service.getSlideBarList({
        parentid: '',
        userid: '',
        isgetsub: 1,
        url: item.path
      }).subscribe(res => {
        if (res) {
          this.slideBarList = res.data;
          //获取副菜单缓存,并将最近列表加入缓存
          let menu = JSON.parse(sessionStorage.getItem('sliderBarList'));
          menu[item.path] = this.slideBarList;
          sessionStorage.setItem('sliderBarList', JSON.stringify(menu));
        }
      });
    }
  }

  //检查副菜单缓存
  static checkSliderMenu() {
    let menu = sessionStorage.getItem('sliderBarList');
    if (!menu) {
      sessionStorage.setItem('sliderBarList', JSON.stringify({}));
    }
  }

  @Input()
  isCollapsed: boolean = false;//左侧导航栏收起展开控制字段
  @Input()
  slideBarList: menuBarList[];
  //滚动溢出
  scrollOver: boolean = false;
}
