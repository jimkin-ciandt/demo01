import {Component, Input, OnInit} from '@angular/core';
import {ActivatedRoute, NavigationEnd, Router} from '@angular/router';
import {filter} from 'rxjs/operators';


@Component({
  selector: 'app-bread-crumbs',
  templateUrl: './bread-crumbs.component.html',
  styleUrls: ['./bread-crumbs.component.css']
})
export class BreadCrumbsComponent implements OnInit {

  constructor(private router:Router,private activeRouter:ActivatedRoute) {
  }

  //折叠相关
  @Input()
  isCollapsed: boolean = false;

  ngOnInit() {
    this.watchRouterState();
    this.breadCrums=[];
    this.getRouterDatas([this.activeRouter]);
  }
  //面包屑数组
  breadCrums:string[]=[];
  //监听路由加载
  watchRouterState(){
    this.router.events.pipe(filter((event)=>{
      return event instanceof NavigationEnd
    })).subscribe((event:NavigationEnd)=>{
          this.breadCrums=[];
         this.getRouterDatas([this.activeRouter]);
    })
  }
  //获取路由状态
  getRouterDatas(config:ActivatedRoute[]){
    if(config.length>0){
      if(config[0].snapshot.data.hasOwnProperty('title')){
        this.breadCrums.push(config[0].snapshot.data['title']);
      }
      if(config[0].children.length){
        this.getRouterDatas(config[0].children);
      }
    }
  }
}
