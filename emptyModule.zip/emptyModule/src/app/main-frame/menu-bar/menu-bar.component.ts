import {Component, EventEmitter, HostBinding, HostListener, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {MainFrameService, menuBarList} from '../main-frame.service';
import {MyCookieSerivce} from '../../app.service.service';
import {ActivatedRoute, Router} from '@angular/router';
import {NzMessageService} from 'ng-zorro-antd';
import {routeAnimationDowns} from '../../app.animations';

@Component({
  selector: 'app-menu-bar',
  templateUrl: './menu-bar.component.html',
  styleUrls: ['./menu-bar.component.css'],
  animations: [routeAnimationDowns]
})
export class MenuBarComponent implements OnInit {

  constructor(private service: MainFrameService, private cookie: MyCookieSerivce, private avtiveRouter: ActivatedRoute, private router: Router, private mess: NzMessageService) {

  }

  @HostBinding('@routeAnimationDown') routeAnimationDown = true;
  @HostBinding('style.display') display = 'block';

  ngOnInit() {
    this.getEmpName();//获取用户名
  }

  //展开收起参数
  @Input()
  toggleSlideParam: boolean = false;
  //发送展开收起事件
  @Output()
  toggleSlideParamChange: EventEmitter<boolean> = new EventEmitter();
  //当前模块url，通过此url获取子菜单
  @Output()
  currentUrlChange: EventEmitter<string> = new EventEmitter();
  //判断搜索框聚焦后尺寸
  isSearchFocused: boolean = false;
  //用户姓名字段
  empName:string='';
  //获取用户姓名
  getEmpName(){
    this.service.getEmpName().subscribe(res=>{
      if(res){
        this.empName=res['data'];
      }
    })
  }
  //搜索焦点事件
  searchFocus() {
    this.isSearchFocused = !this.isSearchFocused;
  }
  //注销方法
  logOut() {
    this.service.logout().subscribe(res=>{});
    this.router.navigateByUrl('/login');
    this.cookie.deleteCookie('equipLogin');
  }
}
