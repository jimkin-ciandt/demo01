import {AfterViewInit, Component, OnDestroy, OnInit} from '@angular/core';
import {zoomIn, zoomOut} from '../../app.animations';


@Component({
  selector: 'app-scroll-to-top',
  templateUrl: './scroll-to-top.component.html',
  styleUrls: ['./scroll-to-top.component.css'],
  animations:[zoomIn,zoomOut]
})
export class ScrollToTopComponent implements OnInit, AfterViewInit, OnDestroy {

  constructor() {
  }

  ngOnInit() {
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.scrollWatcher();
    }, 100);
  }

  ngOnDestroy(): void {
    this.removeScrollWatcher();//消除监听
  }

  //是否显示返回顶部
  isShow: boolean = false;
  //监听处理函数
  scrollHandler: any;

  //设置滚动监听
  scrollWatcher() {
    let mainDom = document.getElementById('mainFrameWrap');
    let father = this;
    this.scrollHandler = () => {
      if (mainDom.scrollTop > 100) {
        father.isShow = true;
      }
      else {
        father.isShow = false;
      }
    };
    mainDom.addEventListener('scroll', this.scrollHandler);
  }

  //消除监听
  removeScrollWatcher() {
    let mainDom = document.getElementById('mainFrameWrap');
    mainDom.removeEventListener('scroll', this.scrollHandler);
  }

  //返回顶部
  backToTop() {
    let mainDom = document.getElementById('mainFrameWrap');
    let scrollToTop = () => {
      mainDom.scrollTop = mainDom.scrollTop - 60;
      if (mainDom.scrollTop > 0) {
      window.requestAnimationFrame(scrollToTop);
      }
    };
    window.requestAnimationFrame(scrollToTop);
  }


}
