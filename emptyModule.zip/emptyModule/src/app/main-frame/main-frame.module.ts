/**
 * 宁波琢华软件科技有限公司
 * create by 兰志辉
 * 装备管理主框架导航页
 * */

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainFrameComponent } from './main-frame-component/main-frame.component';
import {MainFrameRoutingModule} from './main-frame.routing.module';
import {MenuBarComponent} from './menu-bar/menu-bar.component';
import {SlideBarComponent} from './slide-bar/slide-bar.component';
import {NgZorroAntdModule, NZ_I18N, NzModalService, zh_CN} from 'ng-zorro-antd';
/** 配置 angular i18n **/
import { registerLocaleData } from '@angular/common';
import zh from '@angular/common/locales/zh';
import {BreadCrumbsComponent} from './bread-crumbs/bread-crumbs.component';
import {MainFrameService} from './main-frame.service';
import {ScrollToTopComponent} from './scroll-to-top/scroll-to-top.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatProgressBarModule} from '@angular/material';
registerLocaleData(zh);
@NgModule({
  imports: [
    CommonModule,
    NgZorroAntdModule,
    MainFrameRoutingModule,
    MatProgressBarModule
  ],
  /** 配置 ng-zorro-antd 国际化 **/
  providers   : [ { provide: NZ_I18N, useValue: zh_CN } ,MainFrameService],
  declarations: [
    MainFrameComponent,
    MenuBarComponent,
    SlideBarComponent,
    BreadCrumbsComponent,
    ScrollToTopComponent
  ]
})
export class MainFrameModule { }
