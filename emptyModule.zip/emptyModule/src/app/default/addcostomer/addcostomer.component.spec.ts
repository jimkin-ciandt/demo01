import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddcostomerComponent } from './addcostomer.component';

describe('AddcostomerComponent', () => {
  let component: AddcostomerComponent;
  let fixture: ComponentFixture<AddcostomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddcostomerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddcostomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
