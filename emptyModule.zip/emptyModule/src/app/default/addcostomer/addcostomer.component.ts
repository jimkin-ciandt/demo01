import { Component, OnInit,TemplateRef } from '@angular/core';
import {AppServiceService} from '../../app.service.service'
import {
  NzDropdownService,
  NzFormatEmitEvent, NzModalService,
  NzNotificationService,
  NzTreeNode,
  NzTreeNodeOptions
} from 'ng-zorro-antd';
import {DefaultService} from '../default-service';
@Component({
  selector: 'app-addcostomer',
  templateUrl: './addcostomer.component.html',
  styleUrls: ['./addcostomer.component.css']
})
export class AddcostomerComponent implements OnInit {

  constructor(private globalService:AppServiceService,private modal: NzModalService,private service:DefaultService) { }

  ngOnInit() {
    this.getProvinceData();
    this.getUserID();
  }
  addUserData={
    address: '',
    city:'',
    county:'',
    name:'',
    phone:'',
    province:'',
    contacts:'',
    userId:''
  }
  //取消按钮
  cancelEdit(){
    this.addUserData={
      address: '',
      city:'',
      county:'',
      name:'',
      phone:'',
      province:'',
      contacts:'',
      userId:''
    }
  }
  //保存按钮
  saveLoading:boolean=false;
  //保存用户信息
  saveUserData(){
    this.saveLoading=true;
    for(let i=0;i<this.provinceData.length;i++){
      if(this.provinceData[i].id==this.addUserData.province){
        this.addUserData.province=this.provinceData[i].name
      }
    }
    this.globalService.postApi(`/api/customer/add?address=${this.addUserData.address}&city=${this.addUserData.city}&contacts=${this.addUserData.contacts}&county=${this.addUserData.county}&name=${this.addUserData.name}&phone=${this.addUserData.phone}&province=${this.addUserData.province}&userId=${this.addUserData.userId}`,null).subscribe(res=>{
      if(res){
        this.saveLoading=false;
        this.modal.closeAll();
      }
    })
    this.addUserData={
      address: '',
      city:'',
      county:'',
      name:'',
      phone:'',
      province:'',
      contacts:'',
      userId:''
    }
    this.saveLoading=false;
  }

  provinceData:any[]=[];
  //获取省份信息
  getProvinceData(){
    this.service.getProvince().subscribe(res=>{
      for(let i=0;i<res.data.length;i++){
        this.provinceData.push(res.data[i]);
      }
    })
  }
  cityid:any;
  cityData:any[]=[];
  getCityData(){
    this.globalService.getApi(null,`/api/common/getByParentId?id=${this.cityid}`).subscribe(res=>{
      if(res){
        for(let i=0;i<res.data.length;i++){
          if(this.cityid==res.data[i].id){
            if(res.data[i].center==null){
              this.cityData.push(res.data[i].name)
            }else {
              this.cityData.push(res.data[i].center)
            }
          }
        }
      }
    })
  }
  serchCity(data){
    this.cityid=data;
    this.getCityData();
    this.cityData.splice(0,this.cityData.length)
  }
  //获取用户id
  getUserID(){
    this.globalService.getApi(null,'/api/user/getlist').subscribe(res=>{
      if(res){
          this.userData=res.data
      }
    })
  }
  userData:any[]=[];
  serchUser(data){
    this.addUserData.userId=data;
  }

}
