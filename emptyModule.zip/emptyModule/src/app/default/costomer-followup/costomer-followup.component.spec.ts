import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CostomerFollowupComponent } from './costomer-followup.component';

describe('CostomerFollowupComponent', () => {
  let component: CostomerFollowupComponent;
  let fixture: ComponentFixture<CostomerFollowupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CostomerFollowupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CostomerFollowupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
