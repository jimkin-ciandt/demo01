import { Component, OnInit,TemplateRef } from '@angular/core';
import {AppServiceService} from '../../app.service.service'
import {
  NzDropdownService,
  NzFormatEmitEvent, NzModalService,
  NzNotificationService,
  NzTreeNode,
  NzTreeNodeOptions
} from 'ng-zorro-antd';
import {DefaultService} from '../default-service';
@Component({
  selector: 'app-costomer-followup',
  templateUrl: './costomer-followup.component.html',
  styleUrls: ['./costomer-followup.component.css']
})
export class CostomerFollowupComponent implements OnInit {

  constructor(private globalService:AppServiceService,private modal: NzModalService,private service:DefaultService) { }

  ngOnInit() {
    this.getlistData();
  }
  data: any[] = [];

  getlistData(){
    this.globalService.postApi('/api/customer/GetList',null).subscribe(res=>{
      if(res){
        this.data=res.data
        console.log(this.data)
      }
    })
  }


}
