import { NgModule,NO_ERRORS_SCHEMA,Compiler  } from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { DefaultRoutingModule } from './default-routing.module';
import { DefaultPageComponent } from './default-page/default-page.component';
import {NgZorroAntdModule} from 'ng-zorro-antd';
import  {NgxEchartsModule} from 'ngx-echarts';

import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { BookkeepingComponent } from './bookkeeping/bookkeeping.component';
import { SumTypebyTypeComponent } from './sum-typeby-type/sum-typeby-type.component';
import { SumbyuserAndCodeComponent } from './sumbyuser-and-code/sumbyuser-and-code.component';
import { SumbymonthComponent } from './sumbymonth/sumbymonth.component';
import {CommonControlsModule} from '../common-controls/common-controls.module';
import {DefaultService} from './default-service';
import { CustorManagementComponent } from './custor-management/custor-management.component';
import { DefaultComponent } from './default.component';
import { CostomerFollowupComponent } from './costomer-followup/costomer-followup.component';
import { AddcostomerComponent } from './addcostomer/addcostomer.component';

@NgModule({
  declarations: [DefaultPageComponent, BookkeepingComponent, SumTypebyTypeComponent, SumbyuserAndCodeComponent, SumbymonthComponent, CustorManagementComponent, DefaultComponent, CostomerFollowupComponent, AddcostomerComponent],
  imports: [
    NgxEchartsModule,
    HttpClientModule,
    FormsModule,
    CommonModule,
    DefaultRoutingModule,
    CommonControlsModule,
    NgZorroAntdModule,
    ReactiveFormsModule
  ],
  providers:[DefaultService]
})
export class DefaultModule { }
