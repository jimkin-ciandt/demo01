import { Component, OnInit } from '@angular/core';
import {NzFormatEmitEvent, NzModalService, NzTreeNode, NzTreeNodeOptions} from 'ng-zorro-antd';
import {AppServiceService} from '../../app.service.service';

@Component({
  selector: 'app-sum-typeby-type',
  templateUrl: './sum-typeby-type.component.html',
  styleUrls: ['./sum-typeby-type.component.css']
})
export class SumTypebyTypeComponent implements OnInit {

  constructor(private service:AppServiceService,private modal: NzModalService) { }
  /**
   * 时间段改变
   */
  dateRange
  timePeriodChange(time:Date[]){
    let month=time[0].getMonth()+1;
    let date=time[0].getDate();
    let montho=time[1].getMonth()+1;
    let dateo=time[1].getDate();
    let num:string="0";
    let numo:string="0";
    let numt:string="0";
    let numr:string="0";
    if(month>=10){
      num=""
    }
    if(date>=10){
      numo="";
    }
    if(montho>=10){
      numt="";
    }
    if(dateo>=10){
      numr="";
    }
    this.ParametersData.begin=time[0].getFullYear() + '-' + num+(time[0].getMonth() + 1) + '-' + numo+time[0].getDate();
    this.ParametersData.end=time[1].getFullYear() + '-' + numt+(time[1].getMonth() + 1) + '-' + numr+time[1].getDate();
  }
  /*
  * 树结构
  * */
  //已选择的节点
  activedNode: NzTreeNode;
  //列表树控件
  menuNodes: NzTreeNodeOptions[] = [];
  //编辑后的字段
  moduleSetting = {
    "id": "",
    "parentid": "",
    "name": "",
    "remark": "",
    "io": "",
    "code": ""
  };
  //选中节点
  activeNode(data: NzFormatEmitEvent) {
    this.activedNode = data.node;
    this.moduleSetting.name = this.activedNode.origin['name'];
    this.moduleSetting.id=this.activedNode.origin['id'];
    this.moduleSetting.code=this.activedNode.origin['code'];
    this.moduleSetting.remark=this.activedNode.origin['remark'];
    this.moduleSetting.io=this.activedNode.origin['io'];
    this.moduleSetting.parentid=this.activedNode.origin['parentid'];
    this.ParametersData.code=this.activedNode.origin['code'];
  }
  //双击点击
  openFolder(data: NzTreeNode | NzFormatEmitEvent): void {
    if (data instanceof NzTreeNode) {
      data.isExpanded = !data.isExpanded;
    } else {
      data.node.isExpanded = !data.node.isExpanded;
    }
  }
  //获取树列表数据
  getlist(){
    return this.service.getApi(null,'/api/typetree/GetTreeList');
  }
  //获取树菜单列表
  getMenuTree() {
    this.getlist().subscribe(res => {
      if (res) {
        let filterData = (data: any) => {
          for (let i = 0; i < data.length; i++) {
            data[i]['title'] = data[i]['name'];
            data[i]['key'] = data[i]['code'];
            data[i]['children'] = data[i]['Subs'];
            if (data[i]['children'].length) {
              data[i]['isLeaf']=false
              filterData(data[i]['children']);
            }else {
              data[i]['isLeaf']=true;
            }
          }
        };
        filterData(res['data']);
        this.menuNodes = res['data'];
      }
    });
  }
  ngOnInit() {
    this.getMenuTree();
  }
  eitherData:boolean=true;
  eitherchart:boolean=false;
  /**
   *树状图
   */
  //查询按钮
  queryData(){
    this.getHistogramData();
  }
  //get SumByUserAndTypeCode
  getSumByUserType(params){
    return this.service.getApi( params,'/api/bill/SumTypeByType')
  }
  //柱状图明细
  ParametersData={
    begin:"",
    code:"",
    end:""
  }
  sumData:any[]=[];
  sumByTyep_options:any;
  listLoading:boolean=false;
  getHistogramData(){
    this.listLoading=true;
    this.getSumByUserType(this.ParametersData).subscribe(res=>{
      var nameData=[];
      var numData=[];
      if(res.data.length==0){
        maxData=0;
        this.eitherData=true
        this.eitherchart=false
      }else {
        this.eitherchart=true;
        this.eitherData=false;
        this.sumData=res.data;
        var maxData=res.data.length;
        for(let i=0;i<res.data.length;i++){
          nameData.push(res.data[i][1]);
          numData.push((res.data[i][0]));
        }
      }
      this.listLoading=false
      //赋值
      this.sumByTyep_options=this.setPieChart(nameData,numData,maxData);
    })
  }
  setPieChart(nameData,numData,maxData){
    let d={
      value:'',
      name:''
    }
    let arr:any=[]
    for(let i=0;i<this.sumData.length;i++){
      d={
        value:this.sumData[i][0],
        name:this.sumData[i][1]+":"+this.sumData[i][0]
      }
      arr.push(d);
    }
    console.log(arr);
    var option={
      series:[{
        type:'pie',
        radius:'55%',
        data:arr
        }
      ]
    }
    return option;

  }

}
