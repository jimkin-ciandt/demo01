import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SumTypebyTypeComponent } from './sum-typeby-type.component';

describe('SumTypebyTypeComponent', () => {
  let component: SumTypebyTypeComponent;
  let fixture: ComponentFixture<SumTypebyTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SumTypebyTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SumTypebyTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
