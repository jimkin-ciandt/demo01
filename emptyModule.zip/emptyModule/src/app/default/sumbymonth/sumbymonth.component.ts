import { Component, OnInit,TemplateRef } from '@angular/core';
import {AppServiceService} from '../../app.service.service'
import {
  NzDropdownService,
  NzFormatEmitEvent, NzModalService,
  NzNotificationService,
  NzTreeNode,
  NzTreeNodeOptions
} from 'ng-zorro-antd';

@Component({
  selector: 'app-sumbymonth',
  templateUrl: './sumbymonth.component.html',
  styleUrls: ['./sumbymonth.component.css']
})
export class SumbymonthComponent implements OnInit {

  constructor(private service:AppServiceService) { }
  //时间
  dateRange;
  ngOnInit() {
    this.getlistData();
  }
  //变量
  getformatDay(str:number){
    if(str >= 10)
      return str;
    else
      return "0" + str;
  }
  //时间改变监听
  timePeriodChange(time:Date[]){
    this.detail.begin=time[0].getFullYear() + '-' + this.getformatDay((time[0].getMonth() + 1)) + '-' + this.getformatDay(time[0].getDate());
    this.detail.end=time[1].getFullYear() + '-' + this.getformatDay((time[1].getMonth() + 1)) + '-' + this.getformatDay(time[1].getDate());
    this.getlistData();
  }
  //获取明细
  detail={
    begin:'',
    end:''
  }
  //获取按月数据
  getSumMonthData(params){
    return this.service.getApi(params,'/api/bill/SumByMonth')
  }
  eitherchart:boolean=false;
  eitherData:boolean=true;
  //获取图方法
  sumData:any[]=[];
  getlistData(){
    this.getSumMonthData(this.detail).subscribe(res=>{
      console.log(res);
      var xData=[];
      var yData=[];
      var typeData=[];
      if(res.data.length>0){
        this.eitherchart=true;
        this.eitherData=false;
        this.sumData=res.data;
        for(let i=0;i<res.data.length;i++){
          xData.push(res.data[i][1]);
          yData.push(res.data[i][0]);
          typeData.push(res.data[i][2]);
        }
        var max = Math.max.apply(null,yData);
      }else {
        this.eitherData=true
        this.eitherchart=false
      }
      this.sumByMonth_options=this.setEditorChart(xData,max,typeData);
    })

  }
  //图数据源
  sumByMonth_options:any;
  //图数据包装
  setEditorChart(xData,yData,tData){
    for(var i=0;i<xData.length;i++){
      for(var j=i+1;j<xData.length;j++){
        if(xData[i]===xData[j]){
          xData.splice(j,1)
        }
      }
    }
    let arrJ:any=[];
    let arrC:any=[];
    for(let i=0;i<this.sumData.length;i++){
      if(this.sumData[i][2]==1){
        arrJ.push(this.sumData[i][0]);
      }else {
        arrC.push(this.sumData[i][0])
      }
    }
    console.log(arrJ);
    var allData:[]=[];
    var option={
      //样式
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          crossStyle: {
            color: '#999'
          }
        }
      },
      toolbox: {
        feature: {
          dataView: {show: true, readOnly: false},
          magicType: {show: true, type: ['line', 'bar']},
          restore: {show: true},
          saveAsImage: {show: true}
        }
      },
      //顶部数据
      legend:{
        data:['月出项','月进项','月出比']
      },//x轴
      xAxis:[
        {
          type:'category',
          axisPointer:{
            type:'shadow'
          },
          data:xData
        }
      ],//y轴
      yAxis:[
        {
          type:'value',
          name:'金额',
          min:0,
          max:yData,
          axisLabel:{
            formatter:'{value}￥'
          }
        }
      ],
      //数据源
      series:[
        {
          name:'进项',
          type:'bar',
          data:arrJ
        },
        {
          name:'出项',
          type:'bar',
          data:arrC
        }
      ]
    }
    return option;
  }


}
