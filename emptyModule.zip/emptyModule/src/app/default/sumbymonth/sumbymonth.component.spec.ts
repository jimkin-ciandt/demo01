import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SumbymonthComponent } from './sumbymonth.component';

describe('SumbymonthComponent', () => {
  let component: SumbymonthComponent;
  let fixture: ComponentFixture<SumbymonthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SumbymonthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SumbymonthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
