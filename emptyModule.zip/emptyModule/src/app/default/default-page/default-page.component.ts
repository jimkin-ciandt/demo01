import { Component, HostBinding, OnDestroy, OnInit } from '@angular/core';
import {AppServiceService} from '../../app.service.service'
import {HttpClient,HttpHeaders} from '@angular/common/http';
import {
  NzDropdownService,
  NzFormatEmitEvent, NzModalService,
  NzNotificationService,
  NzTreeNode,
  NzTreeNodeOptions
} from 'ng-zorro-antd';
import {fadeIn} from '../../app.animations';
import { PARAMETERS } from '@angular/core/src/util/decorators';

@Component({
  selector: 'app-default-page',
  templateUrl: './default-page.component.html',
  styleUrls: ['./default-page.component.css']
})
export class DefaultPageComponent implements OnInit {

  constructor(private httpClient: HttpClient,private service:AppServiceService,private globalService:AppServiceService,private modal: NzModalService,private nzDropdownService: NzDropdownService, private toa: NzNotificationService) { }

  ngOnInit() {
    this.getMenuTree();//获取模块树
  }
  ngOnDestroy() {
    this.modal.closeAll();
  }
  //列表树控件
  menuNodes: NzTreeNodeOptions[] = [];

  openFolder(data: NzTreeNode | NzFormatEmitEvent): void {
    if (data instanceof NzTreeNode) {
      data.isExpanded = !data.isExpanded;
    } else {
      data.node.isExpanded = !data.node.isExpanded;
    }
  }
  getlist(){
    return this.service.getApi(null,'/api/typetree/GetTreeList');
  }
  //获取菜单列表
  getMenuTree() {
    this.getlist().subscribe(res => {
      if (res) {
        let filterData = (data: any) => {
          for (let i = 0; i < data.length; i++) {
            data[i]['title'] = data[i]['name'];
            data[i]['key'] = data[i]['code'];

            data[i]['children'] = data[i]['Subs'];
            if (data[i]['children'].length) {
              data[i]['isLeaf']=false
              filterData(data[i]['children']);
            }else {
              data[i]['isLeaf']=true;
            }
          }
        };
        filterData(res['data']);
        this.menuNodes = res['data'];
      }
    });
  }
  //编辑出入项

  /**
   * 编辑操作相关
   * */
    //已选择的节点
  activedNode: NzTreeNode;

  //选中节点
  activeNode(data: NzFormatEmitEvent) {
    this.activedNode = data.node;
    this.moduleSetting.name = this.activedNode.origin['name'];
    this.moduleSetting.id=this.activedNode.origin['id'];
    this.moduleSetting.code=this.activedNode.origin['code'];
    this.moduleSetting.remark=this.activedNode.origin['remark'];
    this.moduleSetting.io=this.activedNode.origin['io'];
    this.moduleSetting.parentid=this.activedNode.origin['parentid'];
  }
  //模块类型
  moduleType: string = 'A';
  //编辑后的字段
  moduleSetting = {
    "id": "",
    "parentid": "",
    "name": "",
    "remark": "",
    "io": "",
    "code": ""
  };
  ic:string="进出项";
  //重置属性
  reset() {
    this.moduleSetting = {
      "id": "",
      "parentid": "",
      "name": "",
      "remark": "",
      "io": "",
      "code": ""
    };
  }
  //保存loading
  saveLoading: boolean = false;
  
  //保存方法
  saveSettings() {
    this.saveLoading = true;
    if (this.moduleSetting.parentid) {
      this.service.postApi(`/api/typetree/Add?id=${this.moduleSetting.id}&parentid=${this.moduleSetting.parentid}&name=${this.moduleSetting.name}&remark=${this.moduleSetting.remark}&io=${this.moduleSetting.io}&code=${this.moduleSetting.code}`, null).subscribe(res => {
        if (res) {
          console.log(res)
          this.getMenuTree();
          this.reset();
          this.toa.success('提示', '保存成功');
          this.saveLoading = false;
          this.getlist();
        }
        this.saveLoading = false;
      });
    } else {
    this.moduleSetting.parentid = this.parentid;
    this.service.postApi(`/api/typetree/Add?id=${this.moduleSetting.id}&parentid=${this.moduleSetting.parentid}&name=${this.moduleSetting.name}&remark=${this.moduleSetting.remark}&io=${this.moduleSetting.io}&code=${this.moduleSetting.code}`, null).subscribe(res => {
      if (res) {
        console.log(res)
        this.getMenuTree();
        this.reset();
        this.toa.success('提示', '保存成功');
        this.saveLoading = false;
        this.getlist();
      }
      this.saveLoading = false;
    });
    }
  }

  //删除loading
  deleteLoading: boolean = false;
  deleteModules(params){
    return this.service.postApi(`/api/typetree/del?id=${this.moduleSetting.id}&parentid${this.moduleSetting.parentid}&name=${this.moduleSetting.name}&remark=${this.moduleSetting.remark}&io=${this.moduleSetting.io}&code=${this.moduleSetting.code}`,null);
  }
  //删除模块节点
  deleteModule() {
    this.modal.confirm({
      nzTitle: '提示',
      nzContent: `您确定删除【${this.moduleSetting.name}】吗?`,
      nzOkText: '确定',
      nzCancelText: '取消',
      nzOkLoading: this.deleteLoading,
      nzOnOk: () => {
        return new Promise((resolve, reject) => {
          this.deleteLoading = true;
          this.deleteModules({
            id:this.moduleSetting.id
          }).subscribe(res => {
            if (res) {
              resolve();
              this.deleteLoading = false;
              this.toa.success('提示', '删除成功!');
              this.reset();
              this.getMenuTree();
            }
            else {
              this.deleteLoading = false;
              reject();

            }
          });
        });
      }
    });
  }
  parentid="";
  //新增同/子集
  addChild(type) {

    this.getPageCode(type);
  }
  getPageCode(type) {
    let postdata = {
      code: this.activedNode.origin.code,
      id: ''
    };
    switch (type) {
      case 0:
        this.parentid = this.activedNode.origin.parentid;
        postdata.id = this.activedNode.origin.parentid ? this.activedNode.origin.parentid : '';
        this.moduleSetting.parentid = this.activedNode.origin.parentid;
        this.moduleSetting.id = '';
        this.moduleSetting.name = '';
        break;
      case 1:
        this.parentid = this.activedNode.origin.id;
        postdata.id = this.activedNode.origin.id ? this.activedNode.origin.id : '';
        this.moduleSetting.parentid = this.moduleSetting.id;
        this.moduleSetting.id = '';
        this.moduleSetting.remark='';
        this.moduleSetting.name = this.activedNode.origin.name;
        this.moduleSetting.name = '';
        break;
    }

  }


}
