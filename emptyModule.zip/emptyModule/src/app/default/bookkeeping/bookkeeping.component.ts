import { Component, OnInit,TemplateRef } from '@angular/core';
import {AppServiceService} from '../../app.service.service'
import {
  NzDropdownService,
  NzFormatEmitEvent, NzModalService,
  NzNotificationService,
  NzTreeNode,
  NzTreeNodeOptions
} from 'ng-zorro-antd';
import {DefaultService} from '../default-service';
import {el} from '@angular/platform-browser/testing/src/browser_util';
@Component({
  selector: 'app-bookkeeping',
  templateUrl: './bookkeeping.component.html',
  styleUrls: ['./bookkeeping.component.css']
})
export class BookkeepingComponent implements OnInit {

  constructor(private service:AppServiceService,private modal: NzModalService,private defauSr:DefaultService) { }

  //查询按钮
  queryData(){
    this.getlistData();
  }
  //备注信息
  remark:any="";

  //时间段改变
  dateRange;

  getformatDay(str:number){
    if(str >= 10)
      return str;
    else
      return "0" + str;
  }
  timePeriodChange(time:Date[]){
    this.queryData1.DateStart=time[0].getFullYear() + '-' + this.getformatDay((time[0].getMonth() + 1)) + '-' + this.getformatDay(time[0].getDate());
    this.queryData1.DateEnd=time[1].getFullYear() + '-' + this.getformatDay((time[1].getMonth() + 1)) + '-' + this.getformatDay(time[1].getDate());
  }

  /**
   * 获取列表数据
   */

  queryData1={
    userId:"",
    DateStart:"",
    DateEnd:"",
    Remark:"",
    pageSize:10,
    pageIndex:1,
    pager:true
    };
  getBKdate(){
    return this.service.getApi(this.queryData1,`/api/bill/getlist`);
  }
  //是否显示下载图标
  listData:any[]=[];
  getlistData(isPaging?: boolean){
    this.listLoading = true;
    this.getBKdate().subscribe(res=>{
      if(res){
        this.listData=res['data'];
        this.totalItems=res['dataCount'];
      }
      this.listLoading=false;
    })
  }
  pageSizeChange(e) {
    this.queryData1.pageSize = e;
    this.queryData1.pageIndex = 1;
    this.getlistData();
  }
  pageIndexChange(e) {
    this.queryData1.pageIndex = e ;
    this.getlistData();
  }
  listLoading:boolean=false;
  //总页数
  totalItems:number=0;
  ngOnInit() {
    this.getlistData();
    this.getPersonData();
  }
  //详情字段
  detailInfo={
    'billDate':'',
    'moneny':'',
    'remark':'',
    'io':'',
    'typeCode':'',
    'types':''
  }
    /**
     *增加模板操作
     */
  registerNew(title: TemplateRef<{}>, content: TemplateRef<{}>, footer: TemplateRef<{}>) {
    this.detailInfo = {
      'billDate':'',
      'moneny':'',
      'remark':'',
      'io':'',
      'typeCode':'',
      'types':''
    };
    this.modal.create({
      nzTitle: title,
      nzContent: content,
      nzFooter: footer,
      nzWidth: 500
    });
    this.getDefaultData();
    this.getPersonData();
  }
  //经手人数据
  ePersonData:any[]=[];
  //获取经办人数据
  getPersonData(){
    this.service.getApi(null,'/api/user/getlist').subscribe(res=>{
      if(res){
        let filterData=(data)=>{
          for (let i = 0; i < data.length; i++) {
            data[i]['label'] = data[i]['name'];
            data[i]['isLeaf'] = true;
          }
        }
        filterData(res['data']);
        this.ePersonData=res['data'];
      }
    })
  }
  //下拉框数据源
  nzOptions:any[]=[];
  //获取default列表数据
  getDefaultList(){
    return this.service.getApi(null,'/api/typetree/GetTreeList');
  }
  getDefaultData(){
    this.getDefaultList().subscribe(res=>{
      if(res){
        let filterData=(data)=>{
          for (let i = 0; i < data.length; i++) {
            data[i]['label'] = data[i]['name'];
            data[i]['code'] = data[i]['code'];
            data[i]['children'] = data[i]['Subs'];
            if (data[i]['children'].length) {
              data[i]['isLeaf']=false
              filterData(data[i]['children']);
            }else {
              data[i]['isLeaf']=true;
            }
          }
        }
        filterData(res['data']);
        this.nzOptions = res['data'];
      }
    })
  }
  //删除标签
  confirm(data){
    this.deleteD=data.id;
    this.service.postApi(`/api/bill/del?id=${this.deleteD}`,null).subscribe(res=>{
      if(res){
        this.getlistData();
        this.listLoading=false;
        console.log('删除成功')
      }
    })
  }
  deleteD:any;
  //下载附件
  downFile(data){
    this.service.getWebConfig().subscribe(res=>{
      window.open(res.fileRemote+data.attchs[0].src);
    })
  }
  //添加附件
  //保存按钮
  timeChange(time){
    this.billDate=time.getFullYear() + '/' + this.getformatDay((time.getMonth() + 1)) + '/' + this.getformatDay(time.getDate());

  }
  selectCode(data){
    this.typename=data['option']['label'];
    this.io=data['option']['io']
    this.typeId=data['option']['id']
  }
  selectPerson(data){
    this.queryData1.userId=data['option']['id']
    this.userId=data['option']['id'];
  }
  selectPersont(data){
    this.queryData1.userId=data['option']['id']
  }
  mPerson="";
  ePerson="";
  userId="";
  typeId="";
  io="";
  billDate="";
  moneny="";
  typename="";
  remarks="";
  saveLoading:boolean=false;
  //附件信息
  encloseureData={
    attchid:'',
    billId:''
  }
  dothis:boolean=false;
  //文件名称
  fileName:any;
  runP(id:any){
    this.dothis=true;
    this.encloseureData.attchid=id;
    this.fileName=id;
  }
  saveEditOrNew(){
    this.saveLoading=true;
    this.service.postApi(`/api/bill/Add?billDate=${this.billDate}&moneny=${this.moneny}&remark=${this.remarks}&io=${this.io}&types=${this.typeId}&userId=${this.userId}`,null).subscribe(res=>{
      if(res){
        this.encloseureData.billId=res.data.toString();
        this.service.postApi(`/api/bill/Attch?attchid=${this.encloseureData.attchid}&billId=${this.encloseureData.billId}`,null).subscribe(res=>{
          console.log('sss')
        })
        this.getlistData();
        this.saveLoading=false;
        this.modal.closeAll();
      }else {
        this.saveLoading=false;
      }
    })
    this.queryData1.userId='';
    this.saveLoading=false;
    this.fileName='';
  }
  cancelEdit(){
    this.modal.closeAll();
    this.queryData1.userId='';
    this.fileName='';
  }
  //双击事件
  //双击字段详情
  dbDetail={
    timeD:'',
    monenyD:'',
    personD:'',
    remarkD:'',
    typeD:'',
    id:''
  }
  isVisible:boolean=false;
  showModal(data,e): void {
    let io='';
    if(data.io==1){
      io='进项'
    }else {
      io='出项'
    }
    let dt=data.billDate;
    let d = new Date(dt);
    let times=d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate() ;
    this.isVisible = true;
    this.dbDetail.monenyD=data.moneny;
    this.dbDetail.remarkD=data.remark;
    this.dbDetail.typeD=io;
    this.dbDetail.personD=data.userName;
    this.dbDetail.timeD=times;
    this.dbDetail.id=data.id
  }
  handleOk(): void {
    this.isVisible = false;
    if(this.dothis){
      this.service.postApi(`/api/bill/Attch?attchid=${this.encloseureData.attchid}&billId=${this.dbDetail.id}`,null).subscribe(res=>{
        if(res){
          this.getlistData();
        }
      });
    }
    this.fileName='';
  }
  handleCancel(): void {
    this.isVisible = false;
    this.fileName='';
  }
}
