import { Component, OnInit,TemplateRef } from '@angular/core';
import {AppServiceService} from '../../app.service.service'
import {
  NzDropdownService,
  NzFormatEmitEvent, NzModalService,
  NzNotificationService,
  NzTreeNode,
  NzTreeNodeOptions
} from 'ng-zorro-antd';

@Component({
  selector: 'app-sumbyuser-and-code',
  templateUrl: './sumbyuser-and-code.component.html',
  styleUrls: ['./sumbyuser-and-code.component.css']
})
export class SumbyuserAndCodeComponent implements OnInit {

  constructor(private service:AppServiceService,private modal: NzModalService) { }
  /**
   * 时间段改变
   */
  //是否加载中
  listLoading:boolean=false;
  dateRange
  timePeriodChange(time:Date[]){
    let month=time[0].getMonth()+1;
    let date=time[0].getDate();
    let montho=time[1].getMonth()+1;
    let dateo=time[1].getDate();
    let num:string="0";
    let numo:string="0";
    let numt:string="0";
    let numr:string="0";
    if(month>10){
      num=""
    }
    if(date>10){
      numo="";
    }
    if(montho>10){
      numt="";
    }
    if(dateo>10){
      numr="";
    }
    this.ParametersData.begin=time[0].getFullYear() + '-' + num+(time[0].getMonth() + 1) + '-' + numo+time[0].getDate();
    this.ParametersData.end=time[1].getFullYear() + '-' + numt+(time[1].getMonth() + 1) + '-' + numr+time[1].getDate();
  }
  /*
  * 树结构
  * */
  //已选择的节点
  activedNode: NzTreeNode;
  //列表树控件
  menuNodes: NzTreeNodeOptions[] = [];
  //编辑后的字段
  moduleSetting = {
    "id": "",
    "parentid": "",
    "name": "",
    "remark": "",
    "io": "",
    "code": ""
  };
  //选中节点
  activeNode(data: NzFormatEmitEvent) {
    this.activedNode = data.node;
    this.moduleSetting.name = this.activedNode.origin['name'];
    this.moduleSetting.id=this.activedNode.origin['id'];
    this.moduleSetting.code=this.activedNode.origin['code'];
    this.moduleSetting.remark=this.activedNode.origin['remark'];
    this.moduleSetting.io=this.activedNode.origin['io'];
    this.moduleSetting.parentid=this.activedNode.origin['parentid'];
    this.ParametersData.code=this.activedNode.origin['code'];
  }
  //双击点击
  openFolder(data: NzTreeNode | NzFormatEmitEvent): void {
    if (data instanceof NzTreeNode) {
      data.isExpanded = !data.isExpanded;
    } else {
      data.node.isExpanded = !data.node.isExpanded;
    }
  }
  //获取树列表数据
  getlist(){
    return this.service.getApi(null,'/api/typetree/GetTreeList');
  }
  //获取树菜单列表
  getMenuTree() {
    this.getlist().subscribe(res => {
      if (res) {
        let filterData = (data: any) => {
          for (let i = 0; i < data.length; i++) {
            data[i]['title'] = data[i]['name'];
            data[i]['key'] = data[i]['code'];
            data[i]['children'] = data[i]['Subs'];
            if (data[i]['children'].length) {
              data[i]['isLeaf']=false
              filterData(data[i]['children']);
            }else {
              data[i]['isLeaf']=true;
            }
          }
        };
        filterData(res['data']);
        this.menuNodes = res['data'];
      }
    });
  }
  ngOnInit() {
    this.getMenuTree();
  }

  /**
   *树状图
   */
  //查询按钮
  queryData(){
    this.getHistogramData();
  }
  //get SumByUserAndTypeCode
  getSumByUserType(params){
    return this.service.getApi( params,'/api/bill/SumByUserAndTypeCode')
  }
  //柱状图明细
  ParametersData={
    begin:"",
    code:"",
    end:""
  }
  eitherchart:boolean=false;
  eitherData:boolean=true;
  sumByUser_options:any;
  getHistogramData(){
    this.listLoading=true;
    this.getSumByUserType(this.ParametersData).subscribe(res=>{
      var xData=[];
      var yData=[];
      if(res.data.length==0){
        maxData=0;
        this.eitherData=true
        this.eitherchart=false
      }else {
        this.eitherchart=true;
        this.eitherData=false;
        var maxData=res.data.length;
        for(let i=0;i<res.data.length;i++){
          xData.push(res.data[i][1]);
          yData.push(res.data[i][0]);
        }
      }
      this.listLoading=false;
      this.sumByUser_options=this.setEditorChart(xData,yData,maxData);
    })
  }
  setEditorChart(xData, yData, maxData) {
    var dataShadow = [];
    for(var i = 0; i < xData.length; i++) {
      dataShadow.push(maxData);
    }
    var option = {
      color: ['#769ef8'],
      tooltip: {
        trigger: 'axis',
        axisPointer: { // 坐标轴指示器，坐标轴触发有效
          type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
        }
      },
      grid: {
        left: '3%',
        right: '1%',
        bottom: '20%',
        //containLabel: true
      },
      xAxis: [{
        type: 'category',
        data: xData,
        axisTick: {
          alignWithLabel: true
        },
        axisLabel: {
          show: true,
          textStyle: {
            color: '#6e737c'
          }
        },
        axisLine: {
          lineStyle: {
            color: '#eee',
            width: 1, //这里是为了突出显示加上的
          }
        }

      }],
      yAxis: [{
        type: 'value',
        splitLine: {
          show: true,
          lineStyle: {
            // 使用深浅的间隔色
            color: ['#eee']
          }
        },
        axisLabel: {
          show: true,
          formatter:'{value}',
          textStyle: {
            fontSize:8,
            color: '#6e737c'
          }
        },
        axisLine: {
          lineStyle: {
            color: '#eee',
            width: 0, //这里是为了突出显示加上的
          }
        }
      }],
      series: [{ // For shadow
        name: '金额',
        type: 'bar',
        itemStyle: {
          normal: {
            color: 'gold'
          }
        },
        barGap: '-100%',
        barCategoryGap: '70%',
        data: yData,
        animation: false
      }
      ]
    };
    return option;
  }



}
