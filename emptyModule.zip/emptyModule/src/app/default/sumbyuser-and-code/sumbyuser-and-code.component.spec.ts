import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SumbyuserAndCodeComponent } from './sumbyuser-and-code.component';

describe('SumbyuserAndCodeComponent', () => {
  let component: SumbyuserAndCodeComponent;
  let fixture: ComponentFixture<SumbyuserAndCodeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SumbyuserAndCodeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SumbyuserAndCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
