import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {DefaultPageComponent} from './default-page/default-page.component';
import {BookkeepingComponent} from './bookkeeping/bookkeeping.component';
import {SumbyuserAndCodeComponent} from './sumbyuser-and-code/sumbyuser-and-code.component';
import {SumTypebyTypeComponent} from './sum-typeby-type/sum-typeby-type.component';
import {SumbymonthComponent} from './sumbymonth/sumbymonth.component';
import {CustorManagementComponent} from './custor-management/custor-management.component';
import {CostomerFollowupComponent} from './costomer-followup/costomer-followup.component'
import {AddcostomerComponent} from './addcostomer/addcostomer.component';
const routes: Routes = [
  {path:'defaultPage', component: DefaultPageComponent, data: {title: '首页'}},
  {path:'bookKeeping',component:BookkeepingComponent,data:{title: '记账'}},
  {path:'sumbyuer',component:SumbyuserAndCodeComponent,data:{title: '柱状图'}},
  {path:'sumbycode',component:SumTypebyTypeComponent,data:{title: '饼状图'}},
  {path:'sumbymonth',component:SumbymonthComponent,data:{title:'按月总会'}},
  {path:'custorManage',component:CustorManagementComponent,data:{title:'客户管理'}},
  {path:'costomerFollow',component:CostomerFollowupComponent,data:{title:'客户跟进'}},
  {path:'addCostomer',component:AddcostomerComponent,data:{title:'新增用户'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DefaultRoutingModule { }
