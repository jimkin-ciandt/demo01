import {Injectable} from '@angular/core';
import {AppServiceService} from '../app.service.service';
import {extractStyleParams} from '@angular/animations/browser/src/util';

@Injectable()
export class DefaultService{
  constructor(private globService:AppServiceService) {
  }
  //获取主页面列表
  getDefaultList(){
    return this.globService.getApi(null,'/api/typetree/GetTreeList');
  }

  /**
   *获取客户管理数据
   */
  //获取用户信息
  getCustorManage(params){
    return this.globService.postApi('/api/customer/GetList',params);
  }
  //新增用户信息
  getUserAdd(params){
    return this.globService.postApi('/api/customer/add',params);
  }
  //删除用户
  getUserDelete(params){
    return this.globService.postApi('/api/customer/del',params);
  }
  //修改用户信息
  getUserModify(params){
    return this.globService.postApi('/api/customer/update',params);
  }
  //获取省市数据
  getProvince(){
    return this.globService.getApi(null,'/api/common/getProvince');
  }

  /**
   *用户跟进
   */
  getListByCustomerId(params){
    return this.globService.getApi(null, '/api/follow/GetListByCustomerId');
  }
}
