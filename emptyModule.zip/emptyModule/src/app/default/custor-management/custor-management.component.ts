import { Component, OnInit,TemplateRef } from '@angular/core';
import {AppServiceService} from '../../app.service.service'
import {
  NzDropdownService,
  NzFormatEmitEvent, NzModalService,
  NzNotificationService,
  NzTreeNode,
  NzTreeNodeOptions
} from 'ng-zorro-antd';
import {DefaultService} from '../default-service';

@Component({
  selector: 'app-custor-management',
  templateUrl: './custor-management.component.html',
  styleUrls: ['./custor-management.component.css']
})
export class CustorManagementComponent implements OnInit {

  constructor(private globalService:AppServiceService,private modal: NzModalService,private service:DefaultService) { }

  ngOnInit() {
    this.getlistData();
    this.getProvinceData();
  }

  /**
   *主查询字段
   */
  queryDatas={
    Name:'',
    province:'',
    id:''
  }
  provinceData:any[]=[];
  //获取省份信息
  getProvinceData(){
    this.service.getProvince().subscribe(res=>{
      for(let i=0;i<res.data.length;i++){
        this.provinceData.push(res.data[i].name)
      }
    })
  }
  //查询方法
  queryData(){
    this.getlistData();
    console.log(this.queryDatas.province)
  }
  /*
  * 增加用户
  * */
  registerNew(title: TemplateRef<{}>, content: TemplateRef<{}>, footer: TemplateRef<{}>){
    this.modal.create({
        nzTitle: title,
        nzContent: content,
        nzFooter: footer,
        nzWidth: 500
    })
  }
  /*
  * 获取客户列表主数据
  * */
  //总页数
  totalItems:number=0;
  //加载
  listLoading:boolean=false;
  listData:any[]=[];
  getlistData(){
    this.listLoading=true;
    this.globalService.postApi(`/api/customer/GetList?Name=${this.queryDatas.Name}&province=${this.queryDatas.province}`,null).subscribe(res=>{
      if(res){
        this.listData=res.data;
        console.log(res);
      }
      this.listLoading=false
    })
  }
  //页面页数改变触发
  pageSizeChange(e) {

  }
  pageIndexChange(e) {

  }
  //删除用户信息
  confirm(data){
    this.queryDatas.id=data.id;
    this.globalService.postApi(`/api/customer/del?id=${this.queryDatas.id}`,null).subscribe(res=>{
      if(res){
        this.getlistData();
      }
    })
  }
  //修改用户信息
  isVisible:boolean=false;
  //修改用户明细
  modifyUserData={
    address: '',
    city:'',
    county:'',
    name:'',
    phone:'',
    province:''
  }
  modifyUser(data){
    this.isVisible=true;
    this.modifyUserData.name=data.name;
    this.modifyUserData.phone=data.phone;
    this.modifyUserData.province=data.province
    this.modifyUserData.city=data.city;
    this.modifyUserData.county=data.county;
    this.modifyUserData.address=data.address;
  }
  handleOk(){
    this.service.getUserModify(this.modifyUserData).subscribe(res=>{
      if(res){
        this.getlistData();
      }
    })
    this.isVisible=false;
  }
  handleCancel(){
    this.isVisible=false;
  }

  /**
   * 新增用户拟态模板
   */

  //新增用户查询数据
  addUserData={
    address: '',
    city:'',
    county:'',
    name:'',
    phone:'',
    province:'',
    contacts:'',
    userId:''
  }
  //保存按钮
  saveLoading:boolean=false;
  //保存用户信息
  saveUserData(){
    this.saveLoading=true;
    this.service.getUserAdd(this.addUserData).subscribe(res=>{
      if(res){
        this.getlistData();
        this.saveLoading=false;
        this.modal.closeAll();
      }
    })
    this.saveLoading=false;
  }
  //取消按钮
  cancelEdit(){
    this.modal.closeAll();
  }


}
