import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustorManagementComponent } from './custor-management.component';

describe('CustorManagementComponent', () => {
  let component: CustorManagementComponent;
  let fixture: ComponentFixture<CustorManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustorManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustorManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
