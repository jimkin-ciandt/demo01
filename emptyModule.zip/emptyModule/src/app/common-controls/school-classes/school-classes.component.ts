import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {classInfo, CommonControlService} from '../common-control.service';
import { selectDropDownAnimation } from 'ng-zorro-antd/core/animation/select-dropdown-animations';

@Component({
  selector: 'app-school-classes',
  templateUrl: './school-classes.component.html',
  styleUrls: ['./school-classes.component.css']
})
export class SchoolClassesComponent implements OnInit {

  constructor(private service: CommonControlService) {
    this.disable = false;
  }

  ngOnInit() {
  }

  private _schoolID: string;
  private _semesterID: string;

  //学校id
  @Input()
  set schoolID(schoolID: string) {
    this._schoolID = schoolID;
    // id为空时，disable为true
    if(schoolID === ''){
      this.disable = schoolID === '';
      return;
    }
    this.disable = false;
    this.getClassInfoList();

  }

  get schoolID() {
    return this._schoolID;
  }

  //学期id
  @Input()
  set semesterID(semesterID: string) {
    this._semesterID = semesterID;
  };

  get semesterID() {
    return this._semesterID;
  }

  
  @Input()
  isFirst:boolean = false;
  @Input()
  disable:boolean;
  // 当前选择的班级id
  @Input()
  selectedClassID: string = '';
  //班级id改变事件
  @Output()
  selectedClassIDChange: EventEmitter<string> = new EventEmitter();

  //班级改变
  classChanges(id) {
    this.selectedClassIDChange.emit(id);
  }
  /**
   * 获取班级
   * */
    //班级列表
  classListInfo: classInfo[] = [];

  //获取班级
  getClassInfoList() {
    this.service.getClassList({
      'schoolid': this.schoolID,
      'annualid': this.semesterID,
      'startdate': '',
      'enddate': '',
      'category': 0,
      'bayearid': '',
      'pager': {
        'pager': false,
        'pageIndex': 0,
        'pageSize': 0
      }
    }).subscribe(res => {
      if (res) {
        this.classListInfo = res['data'];
        if(this.classListInfo.length){
          if(this.isFirst){
            this.selectedClassID=this.classListInfo[0].id;
            this.selectedClassIDChange.emit(this.selectedClassID);
          }
          else {
          }
        }
          
      }
    });
  }


}
