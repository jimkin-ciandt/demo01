import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SchoolSemesterComponent } from './school-semester.component';

describe('SchoolSemesterComponent', () => {
  let component: SchoolSemesterComponent;
  let fixture: ComponentFixture<SchoolSemesterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SchoolSemesterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SchoolSemesterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
