import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService, semesterInfo} from '../common-control.service';

@Component({
  selector: 'app-school-semester',
  templateUrl: './school-semester.component.html',
  styleUrls: ['./school-semester.component.css']
})
export class SchoolSemesterComponent implements OnInit {

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
  }

  //学校id
  private _schoolID: string;

  //传入的学校id
  @Input()
  set schoolID(schoolID: string) {
    console.log(schoolID,'id');
    if(schoolID!==null){
      this._schoolID = schoolID;
      this.getSemesterBySchoolID(schoolID);
    }
  }

  get schoolID() {
    return this._schoolID;
  }

  //选择的学期id
  @Input()
  selectedSemesterID: string = '';
  @Output()
  selectedSemesterIDChange: EventEmitter<any> = new EventEmitter();


  private _arrSemester: any[] = [];
  @Input()
  set arrSemester(arrSemester: any[]) {
    this._arrSemester = arrSemester;
  }

  get arrSemester() {
    return this._arrSemester;
  }

  @Output()
  arrSemesterChange: EventEmitter<any> = new EventEmitter();


  //学期改变事件
  semesterChange(id) {
    this.selectedSemesterIDChange.emit(id);
    let index = 0;
    for (let i = 0; i < this.semesterList.length; i++) {
      if (this.semesterList[i].bayearid === id) {
        index = i;
        this.semesterDateChange.emit({
          currentSemester:this.semesterList[i],
          allSemester:this.semesterList,
          currentIndex:i
        });
      }
    }
    var data = {
      id:this.selectedSemesterID,
      data:this.semesterList,
      index:index
    }
    this.arrSemesterChange.emit(data);
  }

  //发射已选择的数据
  @Output()
  semesterDateChange: EventEmitter<any> = new EventEmitter();
  //学期数据
  semesterList: semesterInfo[] = [];

  //根据学校id获取学期信息
  getSemesterBySchoolID(id: string) {
    this.semesterList = [];
    this.service.getSemesterBySchoolID({
      'schoolid': id,
      'pager': {
        'pager': false,
        'pageIndex': 0,
        'pageSize': 0
      }
    }).subscribe(res => {
      if (res) {
        this.semesterList = res['data'];
        if (this.semesterList.length) {
          this.selectedSemesterID = this.semesterList[0].bayearid;
          this.selectedSemesterIDChange.emit(this.selectedSemesterID);
          this.semesterDateChange.emit({
            currentSemester:this.semesterList[0],
            allSemester:this.semesterList,
            currentIndex:0
          });
          var data = {
            id:this.selectedSemesterID,
            data:this.semesterList,
            index:0
          }
          this.arrSemesterChange.emit(data);
        }
        else {
          this.selectedSemesterID = '';
          this.selectedSemesterIDChange.emit(this.selectedSemesterID);
        }
      }
    });
  }
}
