import {Component, EventEmitter, HostBinding, Input, OnInit, Output} from '@angular/core';
import {NzNotificationService, UploadFile, UploadXHRArgs} from 'ng-zorro-antd';
import {AppServiceService} from '../../app.service.service';
import {HttpEvent, HttpEventType, HttpResponse} from '@angular/common/http';

@Component({
  selector: 'app-upload-file',
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.css']
})
export class UploadFileComponent implements OnInit {

  constructor(private service: AppServiceService, private notification: NzNotificationService) {
  }

  @HostBinding('style.display') display = 'inline-block';
  @HostBinding('style.margin-right') marginRight = '10px';

  ngOnInit() {
  }
  //上传文件类型
  @Input()
  fileType: string = 'application/vnd.ms-excel';
  //按钮名称
  @Input()
  btnName: string = 'Excel导入';
  //导入loading动画
  @Input()
  importLoading: boolean = false;
  //上传完成后事件
  @Output()
  uploadComplete: EventEmitter<string> = new EventEmitter();
  sendPar(){
    this.uploadComplete.emit(this.attchid);
  }
  //当前文件上传控件文件列表
  fileList: UploadFile[] = [];
  //自定义事件
  customReq = (item: UploadXHRArgs) => {
    const formData = new FormData();
    formData.append('file', item.file as any);
    return this.service.uploadRequest(item.action, formData).subscribe((event: HttpEvent<{}>) => {
      if (event.type === HttpEventType.UploadProgress) {
        if (event.total > 0) {
          // tslint:disable-next-line:no-any
          (event as any).percent = event.loaded / event.total * 100;
        }
        // 处理上传进度条，必须指定 `percent` 属性来表示进度
        item.onProgress(event, item.file);
      }
      else if (event instanceof HttpResponse) {
        item.onSuccess(event.body, item.file, event);
        if (event.body['success']) {
          this.fileList = [];
          this.uploadComplete.emit(event.body['data']['fileId']);
          this.attchid=event.body['data']['fileId']
        }
        else {
          this.notification.error('提示', event.body['message']);
        }
      }
    });
  };
  attchid:any;
  //上传文件状态
  uploadChanges(event) {
    switch (event['type']) {
      case 'start':
        this.importLoading = true;
        break;
      case 'error':
      case 'success':
        this.importLoading = false;
        break;
    }
  }

}
