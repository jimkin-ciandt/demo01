import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SchoolClassroomComponent } from './school-classroom.component';

describe('SchoolClassroomComponent', () => {
  let component: SchoolClassroomComponent;
  let fixture: ComponentFixture<SchoolClassroomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SchoolClassroomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SchoolClassroomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
