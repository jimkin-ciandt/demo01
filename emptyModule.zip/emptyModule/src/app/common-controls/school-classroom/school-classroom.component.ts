import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService} from '../common-control.service';

@Component({
  selector: 'app-school-classroom',
  templateUrl: './school-classroom.component.html',
  styleUrls: ['./school-classroom.component.css']
})
export class SchoolClassroomComponent implements OnInit {

  constructor(private service: CommonControlService) { }

  ngOnInit() {
  }
  _schoolID:string = '';
  // 传入的学校id
  @Input()
  set schoolID(schoolID:string){
    this._schoolID = schoolID;
    this.getclassRoomList(this.schoolID);
  }
  get schoolID(){
    return this._schoolID;
  }
  @Input()
  isShow:boolean = false;
  // 改变是否刷新
  @Input()
  isRefresh: boolean = true;
  @Input()
  disable:boolean;
  // 已选择的教室
  @Input()
  selectedClassroomID: string = '';
  // 教室改变发射事件
  @Output()
  selectedClassroomIDChange: EventEmitter<string> = new EventEmitter();
  // 获取实验室根据学校
  classRoomList:any[] = [];
  getclassRoomList(id){
    if(!id){
      return false;
    }
    this.service.getClassRoomSelectList(
      {
        schoolid:id
      }).subscribe(res=>{
      if(res){
        this.classRoomList = res['data'];
        if (this.isRefresh) {
          this.selectedClassroomID = '';
        }
      }
      if(this.classRoomList.length){
          if(this.isShow){
            if(this.selectedClassroomID == ''){
              this.selectedClassroomID = this.classRoomList[0].id;
              this.selectedClassroomIDChange.emit(this.classRoomList[0].id);
            }
          }
      }
    });
  }
  // 教室改变事件
  roomChanges(id) {
    this.selectedClassroomIDChange.emit(id);
  }
}
