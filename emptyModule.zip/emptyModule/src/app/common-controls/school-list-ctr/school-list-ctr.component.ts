import {Component, EventEmitter, Injectable, Input, OnChanges, OnInit, Output} from '@angular/core';
import {CommonControlService, schoolListInfo} from '../common-control.service';

@Component({
  selector: 'app-school-list-ctr',
  templateUrl: './school-list-ctr.component.html',
  styleUrls: ['./school-list-ctr.component.css']
})
export class SchoolListCtrComponent implements OnInit {

  constructor(private service:CommonControlService) { }
  ngOnInit() {
    this.getSchoolList();//获取学校列表信息
  }
  @Input()
  isFirst:boolean=false;
  //已选择的学校ID
  @Input()
  selectedSchool:string;
  @Output()
  selectedSchoolChange:EventEmitter<string>=new EventEmitter();
  //学校改变选择改变事件
  schoolChanges(data){
    this.selectedSchoolChange.emit(data);
  }
  //学校列表
  schoolListInfo:schoolListInfo[]=[];
  //获取学校列表信息
  getSchoolList(){
    this.service.getSchoolList().subscribe(res=>{
      if(res){
        this.schoolListInfo=<schoolListInfo[]>res['data'];
        //默认显示第一个学校
        if(this.schoolListInfo.length){
          if(this.isFirst){
            this.selectedSchool=this.schoolListInfo[0].id;
            this.selectedSchoolChange.emit(this.schoolListInfo[0].id);
          }
          else {
          }
        }
      }
    });
  }
}
