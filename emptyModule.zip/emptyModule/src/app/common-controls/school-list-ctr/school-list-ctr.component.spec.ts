import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SchoolListCtrComponent } from './school-list-ctr.component';

describe('SchoolListCtrComponent', () => {
  let component: SchoolListCtrComponent;
  let fixture: ComponentFixture<SchoolListCtrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SchoolListCtrComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SchoolListCtrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
