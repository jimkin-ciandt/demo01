import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService, placeListInfo} from '../common-control.service';

@Component({
  selector: 'app-asset-ctr-types',
  templateUrl: './asset-types.component.html',
  styleUrls: ['./asset-types.component.css']
})
export class TypesComponent implements OnInit {

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
  }

  //控件源数据
  nzOptions: any[] = [];
  private _placeIDs: string = '';

  @Input()
  set placeIDs(placeIDs) {
    this._placeIDs = placeIDs;
    this.values = [];
    this.getData(this._placeIDs);
  }

  @Input()
  isDisabled: boolean = false;
  //已选择的值
  @Input()
  values: string[] = [];

  @Output()
  valuesChange: EventEmitter<string[]> = new EventEmitter();

  //选择改变
  onChanges(values: string[]) {
    this.valuesChange.emit(values);
  }

  //选择事件
  @Output()
  selectedCodeChange: EventEmitter<string> = new EventEmitter();
  @Output()
  selectedNameChange: EventEmitter<string> = new EventEmitter();

  //选择
  selectCode(data) {
    this.selectedCodeChange.emit(data['option']['code']);
    this.selectedNameChange.emit(data['option']['title']);
  }

  //获取类型数据
  getData(placeIDs: string) {
    this.service.getAssetTypess({
      id: placeIDs
    }).subscribe(res => {
      this.filterData(res['data']);
    });
  }

  //过滤省市区数据
  filterData(data: placeListInfo[]) {
    for (let i = 0; i < data.length; i++) {
      data[i]['label'] = data[i].title;
      data[i]['value'] = data[i].key;
      data[i]['code'] = data[i].code;
      if (data[i].children && data[i].children.length > 0) {
        this.filterData(data[i].children);
      }
      else {
        data[i]['isLeaf'] = true;
      }
    }
    this.nzOptions = [...data];
  }
}
