import {Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {AppServiceService} from '../../app.service.service';
import {isNewline} from 'codelyzer/angular/styles/cssLexer';

declare var BMap: any;

@Component({
  selector: 'app-baidu-map',
  templateUrl: './baidu-map.component.html',
  styleUrls: ['./baidu-map.component.css']
})
export class BaiduMapComponent implements OnInit, OnChanges, OnDestroy {

  constructor(private service: AppServiceService, private http: HttpClient) {
  }

  ngOnInit(): void {
    this.initMap();
  }

  ngOnChanges(): void {
  }

  ngOnDestroy() {
    //移除地图覆盖物事件监听
    this.removeMarkerHangler();
  }

  @Input()
  addressName: string;
  @Input()
  lng: any;
  @Input()
  lat: any;
  @Output()
  placeChanges: EventEmitter<any> = new EventEmitter();

  placeInfo: any;

  map: any;

  //初始化地图
  initMap() {
    if (this.map) {
      this.map = null;
    }
    //给元素定宽
    document.getElementById('mapWrap').style.width = (window.screen.availWidth - 48) + 'px';
    this.map = new BMap.Map('mapWrap');
    if (this.lng && this.lat) {
      let lng = this.lng;
      let lat = this.lat;
      let newPoint = new BMap.Point(lng, lat);
      this.map.centerAndZoom(newPoint, 19);
      this.addMarkerByPoint(newPoint, this.map);
    }
    else if (this.addressName) {
      let newPoint = new BMap.Point(116.404, 39.915);
      this.map.centerAndZoom(newPoint, 19);
      this.getLocalCityByAddress(this.map, this.addressName);//定位当前城市
    }
    else {
      let newPoint = new BMap.Point(116.404, 39.915);
      this.map.centerAndZoom(newPoint, 19);
      this.getLocalCity(this.map);//定位当前城市
    }
    this.map.enableScrollWheelZoom(true);
    // this.watchMapClick(this.map);

  }

  //定位当前城市
  getLocalCity(map) {
    //定位城市回调
    let handler = (result: any) => {
      let cityName = result.name;
      map.setCenter(cityName);
    };
    let myCity = new BMap.LocalCity();
    myCity.get(handler);
  }

  //当前标准
  currentMarker: any;
  //监听方法处理
  markerDragHandler:any;

  //根据坐标添加标注物
  addMarkerByPoint(point, map) {
    map.clearOverlays();
    this.currentMarker = new BMap.Marker(point);
    this.currentMarker.enableDragging();
    map.addOverlay(this.currentMarker);
    let father = this;
    this.markerDragHandler=function (e) {
      let place = {
        lng: '',
        lat: '',
        address: ''
      };
      place.lng = e.point.lng;
      place.lat = e.point.lat;
      father.placeInfo = place;
      father.placeChanges.emit(father.placeInfo);

    };
    this.currentMarker.addEventListener('dragend',this.markerDragHandler);
  }

  //移除覆盖物监听
  removeMarkerHangler() {
    if (this.currentMarker&&this.markerDragHandler) {
      this.currentMarker.removeEventListener('dragend', this.markerDragHandler);
    }
  }

  //根据地址获取城市坐标
  getLocalCityByAddress(map, addr: string) {
    let myGeo = new BMap.Geocoder();
    // 将地址解析结果显示在地图上,并调整地图视野
    myGeo.getPoint(addr, function (point) {
      if (point) {
        map.centerAndZoom(point, 13);
      }
    }, null);
  }

}
