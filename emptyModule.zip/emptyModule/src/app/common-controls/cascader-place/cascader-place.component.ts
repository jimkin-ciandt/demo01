import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService, placeListInfo} from '../common-control.service';

@Component({
  selector: 'app-cascader-place',
  templateUrl: './cascader-place.component.html',
  styleUrls: ['./cascader-place.component.css']
})
export class CascaderPlaceComponent implements OnInit {

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
    this.getPlaceList();//获取省市区
  }

  nzOptions: any[] = [];
  @Input()
  values: string[] = [];

  @Output()
  valuesChange: EventEmitter<string[]> = new EventEmitter();

  onChanges(values: any): void {
    this.valuesChange.emit(values);
  }

  //获取省市区
  getPlaceList() {
    this.service.getPlaceInfo().subscribe(res => {
      if (res) {
        this.filterData(res['data']);
      }
    });
  }

  //过滤省市区数据
  filterData(data: placeListInfo[]) {
    for (let i = 0; i < data.length; i++) {
      data[i]['label'] = data[i].title;
      data[i]['value'] = data[i].key;
      if (data[i].children && data[i].children.length > 0) {
        this.filterData(data[i].children);
      }
      else {
        data[i]['isLeaf'] = true;
      }
    }
    this.nzOptions = [...data];
  }
}
