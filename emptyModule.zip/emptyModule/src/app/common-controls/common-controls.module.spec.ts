import { CommonControlsModule } from './common-controls.module';

describe('CommonControlsModule', () => {
  let commonControlsModule: CommonControlsModule;

  beforeEach(() => {
    commonControlsModule = new CommonControlsModule();
  });

  it('should create an instance', () => {
    expect(commonControlsModule).toBeTruthy();
  });
});
