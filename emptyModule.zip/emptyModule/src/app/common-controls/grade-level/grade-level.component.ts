import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService, gradeLevelList} from '../common-control.service';

@Component({
  selector: 'app-grade-level',
  templateUrl: './grade-level.component.html',
  styleUrls: ['./grade-level.component.css']

})
export class GradeLevelComponent implements OnInit {

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
    this.getGradeLevelList();
  }
  @Input()
  isDisable:boolean = false;
  //是否显示全部学制
  @Input()
  isShowAll:boolean=false;
  //已选择的学校ID
  @Input()
  gradeLevelID: string='';
  @Output()
  gradeLevelIDChange: EventEmitter<string> = new EventEmitter();

  //学校改变选择改变事件
  gardeLevelChange(data) {
    this.gradeLevelIDChange.emit(data);
  }

  //学校列表
  gradeLevelList: gradeLevelList[] = [];

  //获取学校列表信息
  getGradeLevelList() {
    this.service.getGradeLevel().subscribe(res => {
      this.gradeLevelList = res['data'];
      if(!this.isShowAll&&this.gradeLevelList.length){
        this.gradeLevelID=this.gradeLevelList[0].id;
        this.gradeLevelIDChange.emit(this.gradeLevelID);
      }
    });
  }

}
