import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { CommonControlService } from "../common-control.service";
import { callbackify } from "util";
import { DEC } from "@angular/material";
declare var moment: any;

@Component({
  selector: "app-data-time-pick",
  templateUrl: "./data-time-pick.component.html",
  styleUrls: ["./data-time-pick.component.css"]
})
export class DataTimePickComponent implements OnInit {
  date: any;
  week: any;
  recordOldTime: string; //记录日点击老的时间
  firstSemTimeStart: string; //记录学期的startTime
  firstSemTimeEnd: string; //学期的endTime
  recordNewTime: number; //记录日点击第一次的时间
  recordClickTime: boolean = true; //记录日点击是否是的时间
  dataModal: number;
  monthNum: number;
  weekNum: number;
  timeFanWei:any[]=[];//点击日然后记录下当前点击的日期一周的时间
  @Input()
  schoolId: string;
  _schoolId: string;
  semesterData: any[] = []; //全部学期的数据
  weekItemChoseIndex: string;
  monthItemChoseIndex: string;
  annListLength: number;
  session: any[] = [];
  sessionId: number;
  monent_time: any;
  annalyList: any[] = [];
  getAnallyData: any;
  day_table_up: any[] = [];
  day_table_now: any[] = [];
  day_table_after: any[] = [];
  weekData: any[] = [];
  monthData: any[] = [];
  dat_table_item = {
    num: 0
  };
  recordNewInfo:{
    date: "2019-2-17",
    index: 20,
    isClick: false,
    isShow: true,
    num: 17
  };
  isShow: number = 4;
  startTime: string;
  endTime: string;
  needStartTime: string;
  needEndTime: string;
  sendData: any;
  constructor(private service: CommonControlService) {}
  //当学校发生变化时时间控件日期发生改变
  semeterChange(e) {
    console.log(e, "semester");
    this.semesterData = [];
    this.semesterData = e.data;
    this.startTime = e.data[e.index].startdate;
    var month = new Date(this.startTime).getMonth() + 1;
    this.monent_time = new Date(this.startTime).getFullYear() + "-" + month;
    this.endTime = e.data[e.index].enddate;
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var month_string = month < 10 ? "0" + month : month;
    var day = date.getDate();
    var day_string = day < 10 ? "0" + day : day;
    var endTime = year + "-" + month_string + "-" + day_string + "T00:00:00";
    var endT = year + "-" + month_string + "-" + day_string;
    this.initTimeShow(this.startTime);
    this.initWeek(this.startTime, this.endTime);
    this.iniMontht(this.startTime, this.endTime);
    var startT = this.startTime.indexOf("T");
    var startTime = this.startTime.slice(0, startT);
    var endDates = new Date(this.endTime);
    let endDatesYear = endDates.getFullYear();
    let endDatesMonth = endDates.getMonth() + 1;
    let endDatesDate = endDates.getDate();
    var endTimes = endDatesYear + "-" + endDatesMonth + "-" + endDatesDate;
    this.date = startTime + "至" + endTimes;
    this.sendData.month = 0;
    this.sendData.weekNum = 0;
    this.sendData.dataModel = 1;
    this.sendData.startDate = startTime;
    this.sendData.endDate = endTimes;
    this.needStartTime = startTime;
    this.needEndTime = endTimes;
    this.sendData.session = e.id;
    this.arrDatyTypeChange.emit(this.sendData);
  }

  ngOnInit() {
    this.sessionId = 0;
    this.getAnallyData = {
      schoolid: "",
      pager: {
        pager: false,
        pageIndex: 1,
        pageSize: 0
      },
      id: ""
    };
    this.sendData = {
      month: "",
      weekNum: "",
      dataModel: "",
      startDate: "",
      endDate: "",
      session: ""
    };
    this.week = [
      {
        name: "一"
      },
      {
        name: "二"
      },
      {
        name: "三"
      },
      {
        name: "四"
      },
      {
        name: "五"
      },
      {
        name: "六"
      },
      {
        name: "七"
      }
    ];
  }
  //学期的改变
  next_session() {
    for (let i = 0; i < this.semesterData.length; i++) {
      if (this.semesterData[i].bayearid == this.sessionId) {
        if (i == this.semesterData.length - 1) {
          this.sessionId = this.semesterData[0].bayearid;
        } else {
          this.sessionId = this.semesterData[i + 1].bayearid;
        }
        this.initSem(this.sessionId);
        break;
      } else {
      }
    }
  }

  //学期的点击
  up_session() {
    for (let i = 0; i < this.semesterData.length; i++) {
      if (this.semesterData[i].bayearid == this.sessionId) {
        if (i == 0) {
          this.sessionId = this.semesterData[
            this.semesterData.length - 1
          ].bayearid;
        } else {
          this.sessionId = this.semesterData[i - 1].bayearid;
        }
        this.initSem(this.sessionId);
        break;
      } else {
      }
    }
  }

  //学期改变的方法
  sessionChange(e) {
    this.initSem(e);
  }
  //学期改变初始化
  initSem(e) {
    for (let i = 0; i < this.semesterData.length; i++) {
      if (
        this.semesterData[i].bayearid == e &&
        this.semesterData[i].iscurrent == 1
      ) {
        //当前学期的话选择的就是当前的学期传入的就是开始时间到现在的时间段
        this.startTime = this.semesterData[i].startdate;
        var month = new Date(this.startTime).getMonth() + 1;
        this.monent_time = new Date(this.startTime).getFullYear() + "-" + month;
        this.endTime = this.semesterData[i].enddate;
        var date = new Date();
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var month_string = month < 10 ? "0" + month : month;
        var day = date.getDate();
        var day_string = day < 10 ? "0" + day : day;
        var endTime =
          year + "-" + month_string + "-" + day_string + "T00:00:00";
        this.initTimeShow(this.startTime);
        this.initWeek(this.startTime, this.endTime);
        this.iniMontht(this.startTime, this.endTime);
      } else if (this.semesterData[i].bayearid == e) {
        //选择以前的学期传入的时间段就是从接口上拿到的开始时间和结束时间
        this.startTime = this.semesterData[i].startdate;
        var month = new Date(this.startTime).getMonth() + 1;
        this.monent_time = new Date(this.startTime).getFullYear() + "-" + month;
        this.endTime = this.semesterData[i].enddate;
        this.initTimeShow(this.startTime);
        this.initWeek(this.startTime, this.endTime);
        this.iniMontht(this.startTime, this.endTime);
      }
    }
  }
  //获取某天是星期几
  getDayInWeek(time, callback) {
    //星期天返回的是0;其他星期几就是返回几
    var week = new Date(time).getDay();
    callback(week);
  }

  //获取某个月有几天
  getDayByMonth(year, month, callback) {
    var day = new Date(year, month, 0);
    callback(day.getDate());
  }

  //计算两个时间点相差的月数
  //返回两个日期相差的月数
  MonthsBetw(date1, date2) {
    //用-分成数组
    date1 = date1.split("-");
    date2 = date2.split("-");
    //获取年,月数
    var year1 = parseInt(date1[0]),
      month1 = parseInt(date1[1]),
      year2 = parseInt(date2[0]),
      month2 = parseInt(date2[1]),
      //通过年,月差计算月份差
      months = (year2 - year1) * 12 + (month2 - month1) + 1;
    return months;
  }
  //计算日期控件上面月的//开始时间的月份++
  iniMontht(start, end) {
    let nextmonth = 0;
    this.monthData = [];
    let startDate = new Date(start);
    let endDate = new Date(end);
    let startYear = startDate.getFullYear();
    let endYear = endDate.getFullYear();
    let startMonth = startDate.getMonth() + 1;
    let endMonth = endDate.getMonth() + 1;
    let startDay = startDate.getDate();
    let endDay = endDate.getDate();
    let a = moment([endYear, endMonth, endDay]);
    let b = moment([startYear, startMonth, startDay]);
    // let a = moment([2019,1,29]);
    // let b = moment([2018,8,16])

    let month = this.MonthsBetw(start, end);
    var data = [];
    var otherData = [];
    let start_endDay = moment(
      startYear + "-" + startMonth,
      "YYYY-MM"
    ).daysInMonth();
    let startItem = {
      startTime: startYear + "-" + startMonth + "-" + startDay,
      endTime: startYear + "-" + startMonth + "-" + start_endDay,
      monthData: startMonth,
      year: startYear
    };
    let year = 0;
    data.push(startItem);
    for (let i = 1; i < month - 1; i++) {
      let item_month = startMonth + i;
      if (item_month > 12) {
        nextmonth++;
        year = startYear + 1;
        let item_endDay = moment(
          year + "-" + nextmonth,
          "YYYY-MM"
        ).daysInMonth();
        var item = {
          startTime: year + "-" + nextmonth + "-" + "01",
          endTime: year + "-" + nextmonth + "-" + item_endDay,
          monthData: nextmonth,
          year: year
        };
        otherData.push(JSON.parse(JSON.stringify(item)));
      } else {
        if (item_month < startMonth) {
          let item_endDay = moment(
            year + "-" + item_month,
            "YYYY-MM"
          ).daysInMonth();
          var item = {
            startTime: year + "-" + item_month + "-" + "01",
            endTime: year + "-" + item_month + "-" + item_endDay,
            monthData: item_month,
            year: year
          };
          year = startYear + 1;
          otherData.push(JSON.parse(JSON.stringify(item)));
        } else {
          year = startYear;
          let item_endDay = moment(
            year + "-" + item_month,
            "YYYY-MM"
          ).daysInMonth();
          var item = {
            startTime: year + "-" + item_month + "-" + "01",
            endTime: year + "-" + item_month + "-" + item_endDay,
            monthData: item_month,
            year: year
          };
          data.push(JSON.parse(JSON.stringify(item)));
        }
      }
    }
    if (startYear == endYear) {
      let end_endDay = moment(
        endYear + "-" + endMonth,
        "YYYY-MM"
      ).daysInMonth();
      let endItem = {
        startTime: endYear + "-" + endMonth + "-" + "01",
        endTime: endYear + "-" + endMonth + "-" + endDay,
        monthData: endMonth,
        year: endYear
      };
      data.push(endItem);
    } else {
      let end_endDay = moment(
        endYear + "-" + endMonth,
        "YYYY-MM"
      ).daysInMonth();
      let endItem = {
        startTime: endYear + "-" + endMonth + "-" + "01",
        endTime: endYear + "-" + endMonth + "-" + endDay,
        monthData: endMonth,
        year: endYear
      };
      otherData.push(endItem);
    }
    if (startYear == endYear) {
      //代表
      let needData = {
        year: startYear,
        allData: data
      };
      this.monthData.push(needData);
    } else {
      let needData = {
        year: startYear,
        allData: data
      };
      let endData = {
        year: endYear,
        allData: otherData
      };
      this.monthData.push(needData);
      this.monthData.push(endData);
    }
  }

  //将时间戳转化为日期格式
  add0(m) {
    return m < 10 ? "0" + m : m;
  }

  //格式化时间戳
  format(shijianchuo, callback) {
    //shijianchuo是整数，否则要parseInt转换
    var time = new Date(shijianchuo);
    var y = time.getFullYear();
    var m = time.getMonth() + 1;
    var d = time.getDate();
    var h = time.getHours();
    var mm = time.getMinutes();
    var s = time.getSeconds();
    var time_up = {
      date: "",
      year: 0,
      month: "",
      day: "",
      timeFormat: ""
    };
    time_up.date = y + "-" + this.add0(m) + "-" + this.add0(d);
    time_up.year = y;
    time_up.month = this.add0(m);
    time_up.day = this.add0(d);
    time_up.timeFormat = shijianchuo;
    callback(time_up);
  }

  //计算日期控件上面周的
  initWeek(start, end) {
    let timeForMat = [];
    let allNeedData = [];
    let needDate = [];
    let timeForMat1 = [];
    let startTime = Date.parse(start);
    let endTime = Date.parse(end);
    let num = 0;
    for (let i = startTime; i <= endTime; i = i + 86400000) {
      //先把开始时间和结束时间转化成时间轴来吧时间换算成我所需的参数
      let date_item = {
        date: "",
        year: "",
        month: "",
        day: "",
        index: 0,
        num: num++
      };
      this.format(i, res => {
        date_item.date = res.date;
        date_item.year = res.year;
        date_item.month = res.month;
        date_item.day = res.day;
        date_item.index = i;
      });
      timeForMat.push(date_item); //从开始时间和结束时间拼装成的数据
      timeForMat1.push(date_item);
    }
    this.getDayInWeek(start, res => {
      //获取开始时间是星期几
      let needDate_item = {
        monthIndex: "",
        weekIndex: 0,
        startTime: "",
        endTime: ""
      };
      this.getDayInWeek(end, response => {
        //获取结束时间是星期几
        let needDate_item = {
          monthIndex: "",
          weekIndex: 0,
          startTime: "",
          endTime: ""
        };
        let now_index = 0; //记录要每个周加1
        let firstData_all = [];
        let firstData: any;
        let needData_sure = [];
        let top_sliceData = [];
        let endWeekData = [];
        if (res == 0) {
          //代表星期0是从开始时间开始算
          needDate_item.monthIndex = timeForMat1[0].month;
          needDate_item.weekIndex = 1;
          needDate_item.startTime = timeForMat1[0].date;
          needDate_item.endTime = timeForMat1[0].date;
          firstData = timeForMat1[1];
          top_sliceData = timeForMat.slice(1, timeForMat.length);
        } else {
          firstData = timeForMat1[8 - res]; //从开始时间的第二个星期的星期一开始算
          needDate_item.monthIndex = timeForMat1[0].month;
          needDate_item.weekIndex = timeForMat1[0].num;
          needDate_item.startTime = timeForMat1[0].date;
          needDate_item.endTime = timeForMat1[7 - res].date;
          top_sliceData = timeForMat.slice(8 - res, timeForMat.length);
          let needDate_items = {
            monthIndex: timeForMat[0].month,
            weekIndex: 1,
            startTime: timeForMat[0].date,
            endTime: timeForMat[8 - res].date
          };
          needDate.push(needDate_items);
        }
        if (response == 0) {
          //结束时间的最后一天是星期天
          needData_sure = top_sliceData;
          top_sliceData = [];
        } else {
          needData_sure = top_sliceData.splice(
            0,
            top_sliceData.length - response
          ); //needData_sure数组代表的是截到最后一个星期前的数据
        }
        for (var i = 0; i < needData_sure.length - 1; i++) {
          let needDate_items = {
            monthIndex: "",
            weekIndex: 0,
            startTime: "",
            endTime: ""
          };
          if (now_index === 0 || now_index % 7 === 0) {
            needDate_items.monthIndex = needData_sure[i].month;
            needDate_items.weekIndex = now_index;
            num = now_index + 6;
            needDate_items.startTime = needData_sure[now_index].date;
            needDate_items.endTime = needData_sure[num].date;
            let arr = [needDate_items];
            needDate.push(...arr);
          }
          now_index++;
        }
        let needDate_item1 = {
          monthIndex: "",
          weekIndex: 0,
          startTime: "",
          endTime: ""
        };
        if (top_sliceData.length == 0) {
        } else {
          needDate_item1.monthIndex = top_sliceData[0].month;
          needDate_item1.weekIndex = 0;
          needDate_item1.startTime = top_sliceData[0].date;
          needDate_item1.endTime = top_sliceData[top_sliceData.length - 1].date;
          needDate.push(needDate_item1);
        }
        let needData_item = {
          monthIndex: "",
          weekArr: []
        };
        let needData_all = [];
        for (let j = 0; j < needDate.length; j++) {
          needDate[j].weekNum = j + 1;
          if (j != needDate.length - 1) {
            //排除最后一项
            if (
              needDate[j].monthIndex == needDate[j + 1].monthIndex &&
              j != needDate.length - 2
            ) {
              needData_item.monthIndex = needDate[j].monthIndex;
              needData_item.weekArr.push(needDate[j]);
            } else if (j == needDate.length - 2) {
              needData_item.monthIndex = needDate[j].monthIndex;
              needData_item.weekArr.push(needDate[j]);
              needData_all.push(JSON.parse(JSON.stringify(needData_item)));
              needData_item.monthIndex = "";
              needData_item.weekArr = [];
            } else {
              needData_item.weekArr.push(needDate[j]);
              needData_all.push(JSON.parse(JSON.stringify(needData_item)));
              needData_item.monthIndex = "";
              needData_item.weekArr = [];
            }
          } else {
            let num1 = j - 1;
            if (needDate[j].monthIndex == needDate[num1].monthIndex) {
              needData_all[needData_all.length - 1].weekArr.push(needDate[j]);
            } else {
              needData_item.monthIndex = needDate[j].monthIndex;
              needData_item.weekArr.push(needDate[j]);
              needData_all.push(JSON.parse(JSON.stringify(needData_item)));
            }
          }
        }
        this.weekData = needData_all;
      });
    });
  }

  //计算日期控件上面天的
  initTimeShow(time) {
    let week = 0;
    this.day_table_up = [];
    this.day_table_now = [];
    this.day_table_after = [];
    let selectTime = time;
    let nowTime = new Date(time); //将传进来的时间转化为时间格式
    //let endTime = new Date(end);//传进来的结束时间转化为时间格式
    this.getDayInWeek(time, res => {
      let years = nowTime.getFullYear();
      let months = nowTime.getMonth() + 1;
      let times = years + "-" + months + "-" + "01";
      let a = 0;
      this.getDayInWeek(times, week => {
        //刚进来的时间第一天为星期几？
        if (week > 1 || week == 0) {
          //代表的是要在她前面加上上个月的数据
          this.getDayByMonth(nowTime.getFullYear(), nowTime.getMonth(), res => {
            if (week == 0) {
              var needData = res - 5;
            } else {
              var needData = res - week + 2;
            }
            var month = nowTime.getMonth() + 1;
            for (let i = needData; i <= res; i++) {
              var data = {
                num: 0,
                index: a++,
                date: nowTime.getFullYear() + "-" + month + "-" + i,
                isShow: false, //关于不可点击的判断;
                isClick: false //是否是点击的状态
              };
              data.num = i;
              this.day_table_up.push(data);
            }
            this.getDayByMonth(
              nowTime.getFullYear(),
              nowTime.getMonth() + 1,
              res => {
                var month = nowTime.getMonth() + 1;
                for (let j = 1; j <= res; j++) {
                  var data = {
                    num: 0,
                    index: a++,
                    date: nowTime.getFullYear() + "-" + month + "-" + j,
                    isShow: true,
                    isClick: false //是否是点击的状态
                  };
                  data.num = j;
                  this.day_table_now.push(data);
                }
                this.getDayInWeek(selectTime, res => {
                  var data = [];
                  for (var i = 0; i < this.day_table_now.length; i++) {
                    if (
                      this.day_table_now[i].num < new Date(selectTime).getDate()
                    ) {
                      this.day_table_up.push(this.day_table_now[i]);
                      data.push(i);
                    }
                  }
                  for (var i = 0; i < data.length; i++) {
                    this.day_table_now.splice(0, 1);
                  }
                });
              }
            );
          });
        } else if (week == 1) {
          this.getDayByMonth(
            nowTime.getFullYear(),
            nowTime.getMonth() + 1,
            res => {
              var month = nowTime.getMonth() + 1;
              for (let j = 1; j <= res; j++) {
                var data = {
                  num: 0,
                  index: a++,
                  date: nowTime.getFullYear() + "-" + month + "-" + j,
                  isShow: true,
                  isClick: false //是否是点击的状态
                };
                data.num = j;
                this.day_table_now.push(data);
              }
            }
          );
        }
      });
      let year = nowTime.getFullYear();
      let month = nowTime.getMonth() + 1;
      let day = 0;
      this.getDayByMonth(year, month, res => {
        day = res;
      });
      let time = year + "-" + month + "-" + day;
      this.getDayInWeek(time, res => {
        //获取的这个月的最后一天是星期几
        if (res < 7 && res != 0) {
          for (let i = 1; i <= 7 - res; i++) {
            var data = {
              num: 0,
              index: a++,
              date: time,
              isShow: false,
              isClick: false //是否是点击的状态
            };
            data.num = i;
            this.day_table_after.push(data);
          }
        }
      });
    });
  }

  //时间发生改变
  onValueChange(e) {}

  //时间选择下个月
  next_month() {
    var nowDate = new Date(this.monent_time);
    var year = nowDate.getFullYear();
    var month = nowDate.getMonth();
    if (month == 11) {
      //跨年啦
      year = year + 1;
      month = 1;
    } else {
      //还是在今年
      month = month + 2;
    }
    this.monent_time = year + "-" + month + "-" + "01";
    this.initTimeShow(this.monent_time);
  }

  //时间选择上个月
  up_month() {
    var nowDate = new Date(this.monent_time);
    var year = nowDate.getFullYear();
    var month = nowDate.getMonth();
    if (month == 0) {
      //跨年啦
      year = year - 1;
      month = 12;
    } else {
      //还是在今年
      month = month;
    }
    this.monent_time = year + "-" + month + "-" + "01";
    this.initTimeShow(this.monent_time);
  }

  //模式发生改变
  onModeChange(e) {}

  //旁边月周日大类的点击
  choseItem(number) {
    this.isShow = number;
    this.sendData.month = "";
    this.sendData.weekNum = 0;
    this.sendData.dataModel = 1;
    this.sendData.session = this.sessionId;
    this.sendData.startDate = this.startTime;
    this.sendData.endDate = this.endTime;
    if (number == 4) {
      let startTime = new Date(this.startTime);
      let endTime = new Date(this.endTime);
      let sYear = startTime.getFullYear();
      let sMonth = startTime.getMonth() + 1;
      let sDate = startTime.getDate();
      let eYear = endTime.getFullYear();
      let eMonth = endTime.getMonth() + 1;
      let eDate = endTime.getDate();
      let sTime = sYear + "-" + sMonth + "-" + sDate;
      let eTime = eYear + "-" + eMonth + "-" + eDate;
      this.date = sTime + "至" + eTime;
      this.arrDatyTypeChange.emit(this.sendData);
      this.dateModelChange.emit(number);
    } else if (number == 1) {
      this.monthItemChoseIndex = "";
    } else if (number == 2) {
      this.weekItemChoseIndex = "";
    } else {
      for (let i = 0; this.day_table_now.length; i++) {
        this.day_table_now[i].isClick = false;
      }
    }
  }

  //周的点击
  weekClick(el) {
    this.weekItemChoseIndex = el.weekNum;
    this.date = el.startTime + "至" + el.endTime;
    this.sendData.month = "";
    this.sendData.weekNum = el.weekNum;
    this.sendData.dataModel = 3;
    this.sendData.startDate = el.startTime;
    this.sendData.endDate = el.endTime;
    this.sendData.session = this.sessionId;
    this.arrDatyTypeChange.emit(this.sendData);
  }
  //月的点击
  monthClick(el) {
    this.monthItemChoseIndex = el.monthData;
    this.date = el.startTime + "至" + el.endTime;
    this.sendData.month = parseInt(el.monthData);
    this.sendData.weekNum = 0;
    this.sendData.dataModel = 2;
    this.sendData.startDate = el.startTime;
    this.sendData.endDate = el.endTime;
    this.sendData.session = this.sessionId;
    this.arrDatyTypeChange.emit(this.sendData);
  }
  //第一次点击
  firstClickDay(e){
      this.timeFanWei = [];
      //代表他是第一次点击
      this.recordNewTime = new Date(e.date).getTime();
      this.recordNewInfo = e;
      let endTime = "";
      let arrData = [];
      let index = 0;
      for (let i = 0; i < this.day_table_now.length; i++) {
        this.day_table_now[i].isClick = false;
      }
      this.getDayInWeek(e.date, res => {
        let startTime = e.date;
        for (let i = 0; i < this.day_table_now.length; i++) {
          if (e.index == this.day_table_now[i].index) {
            index = i;
            break;
          }
        }
        if (res == 0) {
          for (var i = 0; i <= 7 - 7; i++) {
            this.day_table_now[index + i].isClick = true;
            endTime = e.date;
          } 
          for(let s =0;s<7;s++){
            let indexd = index-s;
            var data  = this.day_table_now[indexd]
            if(data != undefined){
              this.timeFanWei.push()
            }
          }
          for(i=0;i<this.timeFanWei.length/2;i++){
           var temp=this.timeFanWei[i];
           this.timeFanWei[i]=this.timeFanWei[this.timeFanWei.length-1-i];
           this.timeFanWei[this.timeFanWei.length-1-i]=temp;
            }
        } else {
          for(let i = res-1;i>0;i--){
            let data = this.day_table_now[index-i];
            if(data != undefined){
              this.timeFanWei.push(data)
            }
            
          }
          for(let s = 0;s<=7-res;s++){
            let data = this.day_table_now[index+s];
            if(data != undefined){
              this.timeFanWei.push(data)
            }
          }
          for (var d = 0; d <= 7 - res; d++) {
            if(this.day_table_now[index + d]!=undefined){
              this.day_table_now[index + d].isClick = true;
                endTime = this.day_table_now[index+d].date;
            }
          }
        }
        this.date = startTime + "至" + endTime;
        this.sendData.month = 0;
        this.sendData.weekNum = 0;
        this.sendData.dataModel = 4;
        this.sendData.startDate = startTime;
        this.sendData.endDate = endTime;
        this.sendData.session = this.sessionId;
        this.arrDatyTypeChange.emit(this.sendData);
      });
      this.recordClickTime = false;
  }
  //每个时间点的点击
  item_dayClick(e) {
    if (this.recordClickTime) {
        this.firstClickDay(e)
    } else {
        if(e.num>= this.timeFanWei[0].num && e.num<=this.timeFanWei[this.timeFanWei.length - 1].num){
          for (let i = 0; i < this.day_table_now.length; i++) {
            this.day_table_now[i].isClick = false;
          }
            let index = 0;
           let nowClickTime =  new Date(e.date).getTime();
           let s = 0;
           if(nowClickTime == this.recordNewTime){//第二次点的是和第一次一样的
              s=0;
              for (let i = 0; i < this.day_table_now.length; i++) {
                if (this.recordNewInfo.date == this.day_table_now[i].date) {
                  index = i;
                  break;
                }
              }
              this.day_table_now[index].isClick = true;
              this.date = e.date + "至" + e.date;
              this.sendData.startDate = e.date;
              this.sendData.endDate = e.date;
           }else if(nowClickTime>this.recordNewTime){//第二次点的比第一次大
            let time=nowClickTime-this.recordNewTime;
            s = time/86400000;
            for (let i = 0; i < this.day_table_now.length; i++) {
              if (this.recordNewInfo.date == this.day_table_now[i].date) {
                index = i;
                break;
              }
            }
            for(let i =0;i<=s;i++){
              this.day_table_now[index+i].isClick = true;
            }
            this.date = this.recordNewInfo.date + "至" + e.date;
            this.sendData.startDate = this.recordNewInfo.date;
            this.sendData.endDate = e.date;
           }else if(nowClickTime<this.recordNewTime){//第二次点的比第二次小
             let time=this.recordNewTime-nowClickTime;
             s = time/86400000;
             for (let i = 0; i < this.day_table_now.length; i++) {
               if (e.date == this.day_table_now[i].date) {
                 index = i;
                 break;
               }
             }
             for(let i =0;i<=s;i++){
               this.day_table_now[index+i].isClick = true;
             }
             this.date =e.date + "至" + this.recordNewInfo.date;
             this.sendData.startDate = e.date;
           this.sendData.endDate = this.recordNewInfo.date;
             this.recordNewTime = new Date(e.date).getTime();
             this.recordNewInfo = e;
           }
        
           this.sendData.month = 0;
           this.sendData.weekNum = 0;
           this.sendData.dataModel = 4;
           
           this.sendData.session = this.sessionId;
           this.arrDatyTypeChange.emit(this.sendData);
        }else{
this.firstClickDay(e);
        }
    }
  }

  // @Input()
  // schoolID:string
  //监听上面时间发生变化
  private _dateTime: any;
  @Input()
  set arrDatyType(arrDatyType: any) {
    this._dateTime = arrDatyType;
  }
  get arrDatyType() {
    return this._dateTime;
  }
  @Output()
  arrDatyTypeChange: EventEmitter<string> = new EventEmitter();

  dateChange(e) {
    this.arrDatyTypeChange.emit(e);
  }
  //dateModel
  @Output()
  dateModelChange: EventEmitter<number> = new EventEmitter();
}
