import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataTimePickComponent } from './data-time-pick.component';

describe('DataTimePickComponent', () => {
  let component: DataTimePickComponent;
  let fixture: ComponentFixture<DataTimePickComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataTimePickComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataTimePickComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
