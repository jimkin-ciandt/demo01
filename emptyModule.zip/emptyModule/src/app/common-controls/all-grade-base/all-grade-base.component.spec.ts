import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllGradeBaseComponent } from './all-grade-base.component';

describe('AllGradeBaseComponent', () => {
  let component: AllGradeBaseComponent;
  let fixture: ComponentFixture<AllGradeBaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllGradeBaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllGradeBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
