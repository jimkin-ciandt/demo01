import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DangerousListComponent } from './dangerous-list.component';

describe('DangerousListComponent', () => {
  let component: DangerousListComponent;
  let fixture: ComponentFixture<DangerousListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DangerousListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DangerousListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
