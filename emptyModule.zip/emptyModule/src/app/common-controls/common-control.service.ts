/**
 *宁波琢华软件科技有限公司
 *create by 兰志辉
 *-----公共控件模块服务----
 */
import {Injectable} from '@angular/core';
import {AppServiceService} from '../app.service.service';
import {Observable} from 'rxjs';

@Injectable()
export class CommonControlService {
  constructor(private service: AppServiceService) {
  }

  // 获取年级基础列表
  getGradeBase() {
    return this.service.postApi('/api/BaGrade/GetGradeBase', null);
  }

  //根据学校id去获取班级
  GetGradeBySchool(param) {
    return this.service.postApi('/api/BaGrade/GetGradeBySchool', param);
  }

  //根据学校id去获取学科
  GetCourseList(param) {
    return this.service.postApi('/api/PublicCourse/GetCourseList', param);
  }

  // 获取基础学科
  getSubjectBase() {
    return this.service.postApi('/api/BaSubject/GetSubject', null);
  }

  //根据省市区去获取学校
  GetSchoolInfoByCounty(postData) {
    return this.service.postApi('/api/SchoolInfo/GetSchoolInfoByCounty', postData);
  }

  // 获取学校列表
  getSchoolList(): Observable<any> {
    return this.service.postApi('/api/SchoolInfo/GetSchoolInfo', null);
  }

  //获取所有学期的数据
  GetAllYearSemester(data) {
    return this.service.postApi('api/BaYearSemester/GetAllYearSemester', data);
  }

  // 获取学制信息
  getGradeLevel() {
    return this.service.postApi('/api/SchoolCategory/GetSchoolCategory', null);
  }

  //获取学期信息
  getAnnalyList(data) {
    return this.service.postApi('/api/BaYearSemester/GetAnnualList', data);
  }

  // 获取省市区信息
  getPlaceInfo() {
    return this.service.postApi('/api/common/getProvince', {});
  }

  //通过学校id获取学期信息
  getSemesterBySchoolID(params) {
    return this.service.postApi('/api/BaYearSemester/GetAnnualList', params);
  }

  //通过学校id，学期id获取年级
  getGradeList(params) {
    return this.service.postApi('/api/BaGrade/GetGradeBySchool', params);
  }

  //通过学校id来获取教师
  GetEmployeeDetail(params) {
    return this.service.postApi('/api/Employee/GetEmployeeDetail', params);
  }

  //获取班级信息
  getClassList(params) {
    return this.service.postApi('/api/ClassAdjust/GetClassInfoList', params);
  }

  //获取代理商权限范围
  getAgentScope() {
    return this.service.postApi('/api/EasAgent/GetScopeList', {});
  }

  //通过地区获取学校
  // 获取学校根据省市区
  getSchoolInfoByCounty(params) {
    return this.service.postApi('/api/SchoolInfo/GetSchoolInfoByCounty', params);
  }

  //获取产品列表
  getProductList() {
    return this.service.postApi('/api/EasContract/GetProduct', null);
  }

  // 根据学校获取实验室
  getExperimentRoomBySchool(params) {
    return this.service.postApi('/api/CcMultipurposeApply/GetExperimentRoom', params);
  }

  //获取类别树
  getInstrumentList(params) {
    return this.service.postApi('/api/EpInstrumentCategory/GetCategoryList', params);
  }

  //获取编制列表
  getAuthStrengthList(params) {
    return this.service.postApi('/api/PublicCode/GetCodeByParentCode', params);
  }

  //获取学历列表
  getEduLevelList(params) {
    return this.service.postApi('/api/PublicCode/GetItemsCode', params);
  }

  //资产类型
  getAssetTypess(params) {
    return this.service.postApi('/api/CcAsset/GetAssetList', params);
  }

  //资金来源
  getCapitalSource() {
    return this.service.postApi('/api/PublicCode/GetItemsCode', {
      'parentcode': 'SourceOfFunds',
      'basecode': 'SourceOfFunds'
    });
  }

  //获取教室选择框
  getClassRoomSelectList(params) {
    return this.service.postApi('/api/ClassRoom/GetClassRoomSelectList', params);
  }
  /**
   * 年龄段控件
   * */
  //获取年龄段信息
  getAgeRangeList(){
    return this.service.postApi('/api/Employee/GetAgeList', null);
  }
  /**
   * 多功能教室控件
   * */
  //获取多功能教室控件
  getMultiRoomBase(){
    return this.service.postApi('/api/PublicCode/GetTeacherRoomType', null);
  }
}

//学校数据类型
export interface schoolListInfo {
  'id'?: string
  'fullname'?: string
  'province'?: string
  'city'?: string
  'county'?: string
}

export interface gradeLevelList {
  id?: string
  name?: string
}

export interface gradeBaseList {
  id?: string
  name?: string
}

export interface subjectBaseList {
  id?: string
  name?: string
}

export interface semesterInfo {
  'id'?: string
  'schoolid'?: string
  'yearname'?: string
  'semester'?: number
  'bayearid'?: string
  'iscurrent'?: number
  'startdate'?: string
  'enddate'?: string
  'period'?: any
}

export interface gradeListInfo {
  'id'?: string
  'name'?: string
  'gradebaseid'?: string
}

export interface classInfo {
  'gradeclassname'?: string
  'id'?: string
  'classname'?: string
}

export interface placeSchoolInfo {
  city?: string
  county?: string
  fullname?: string
  id?: string
  province?: string
}

export interface placeListInfo {
  key?: string
  title?: string
  code?: string
  children?: placeListInfo[]
}
