import { Component, OnInit, EventEmitter, Input , Output } from '@angular/core';
import {CommonControlService, gradeBaseList} from '../common-control.service';

@Component({
  selector: 'app-grade-base',
  templateUrl: './grade-base.component.html',
  styleUrls: ['./grade-base.component.css']
})
export class GradeBaseComponent implements OnInit {


  constructor(private service:CommonControlService) { }

  ngOnInit() {
    this.getGradeBaseList();
  }
// 已选择的年级ID
  @Input()// 父提供数据
  selectedGrade: string='';
  @Input()
  isMultiple:boolean=false;
  @Input()
  isFirst:boolean=false;
  @Output()
  selectedGradeChange: EventEmitter<string> = new EventEmitter();
  // 年级改变选择改变事件
  gradeBaseChange(data){
    this.selectedGradeChange.emit(data);
  }
  // 年级列表
  gradeBaseList: gradeBaseList[] = [];
// 获取年级基础列表
  getGradeBaseList(){
    this.service.getGradeBase().subscribe(res=>{
      this.gradeBaseList = res['data'];
      //默认显示第一个年级
      if(this.gradeBaseList.length) {
        if (this.isFirst) {
          this.selectedGrade = this.gradeBaseList[0].id;
          this.selectedGradeChange.emit(this.gradeBaseList[0].id);
        }
      }
    });
  }
}
