import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GradeBaseComponent } from './grade-base.component';

describe('GradeBaseComponent', () => {
  let component: GradeBaseComponent;
  let fixture: ComponentFixture<GradeBaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GradeBaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GradeBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
