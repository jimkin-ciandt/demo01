import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SchoolConditionsComponent } from './school-conditions.component';

describe('SchoolConditionsComponent', () => {
  let component: SchoolConditionsComponent;
  let fixture: ComponentFixture<SchoolConditionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SchoolConditionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SchoolConditionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
