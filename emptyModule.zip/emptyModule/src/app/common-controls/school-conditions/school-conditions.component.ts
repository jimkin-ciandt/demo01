import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService, schoolListInfo} from '../common-control.service';

@Component({
  selector: 'app-school-conditions',
  templateUrl: './school-conditions.component.html',
  styleUrls: ['./school-conditions.component.css']
})
export class SchoolConditionsComponent implements OnInit {
  gradeList: any;

  getData = {
    'countyids': []
  };

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
  }

  _selectedByid: any[];
  @Input()
  isFirst: boolean = false;

  @Input()
  set selectedByid(selectedByid: any[]) {
    this._selectedByid = selectedByid;
    this.getData.countyids = selectedByid;
    this.getSchoolList(this.getData);
  }

  get selectedByid() {
    return this._selectedByid;
  }

  @Output()
  selectedByidChange: EventEmitter<any> = new EventEmitter();

  //已选择的学校ID
  @Input()
  selectedSchool: string;

  @Output()
  selectedSchoolChange: EventEmitter<string> = new EventEmitter();

  //学校改变选择改变事件
  schoolChanges(data) {
    this.selectedSchoolChange.emit(data);
  }

  //学校列表
  schoolListInfo: schoolListInfo[] = [];

  //获取学校列表信息
  getSchoolList(data) {
    this.service.GetSchoolInfoByCounty(data).subscribe(res => {
      if (res) {
        this.schoolListInfo = <schoolListInfo[]>res['data'];
        if (this.isFirst && this.schoolListInfo.length) {
          this.selectedSchool=this.schoolListInfo[0].id;
            this.selectedSchoolChange.emit(this.schoolListInfo[0].id);
        }
        else{
          this.selectedSchoolChange.emit('');
        }
      }
    });
  }
}
