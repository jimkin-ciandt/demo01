import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService} from '../common-control.service';

@Component({
  selector: 'app-capital-source',
  templateUrl: './capital-source.component.html',
  styleUrls: ['./capital-source.component.css']
})
export class CapitalSourceComponent implements OnInit {

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
    this.getCapitalSource();//获取资金来源列表
  }

  //是否显示全部
  @Input()
  isFirst: boolean = false;

  //资金来源列表
  capitalSource: {
    id?: string
    name?: string
  }[] = [];

  //获取资金来源
  getCapitalSource() {
    this.service.getCapitalSource().subscribe(res => {
      this.capitalSource = res['data'];
      if (this.isFirst && this.capitalSource.length) {
        this.selectedCapital = this.capitalSource[0].id;
      }
    });
  }

  //已选择的资金来源
  @Input()
  selectedCapital: string = '';
  //选择事件
  @Output()
  selectedCapitalChange: EventEmitter<string> = new EventEmitter();

  //选择改变
  capitalChanges(id) {
    this.selectedCapitalChange.emit(id);
  }


}
