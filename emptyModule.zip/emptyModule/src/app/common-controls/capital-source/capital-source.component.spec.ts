import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CapitalSourceComponent } from './capital-source.component';

describe('CapitalSourceComponent', () => {
  let component: CapitalSourceComponent;
  let fixture: ComponentFixture<CapitalSourceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CapitalSourceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CapitalSourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
