import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService} from '../common-control.service';

@Component({
  selector: 'app-all-products',
  templateUrl: './all-products.component.html',
  styleUrls: ['./all-products.component.css']
})
export class AllProductsComponent implements OnInit {

  constructor(private service:CommonControlService) { }

  ngOnInit() {
    this.getProductList();//初始化时获取产品列表
  }
  //产品列表
  productList:{id?:string,name?:string}[]=[];
  //获取产品列表
  getProductList(){
    this.service.getProductList().subscribe(res=>{
      if(res){
        this.productList=res['data'];
        if(this.productList.length){
          this.product=this.productList[0].id;
          this.productChange.emit(this.product);
        }
      }
    })
  }
  //当前已选择的产品id
  @Input()
  product:string;
  //产品改变发射
  @Output()
  productChange:EventEmitter<string>=new EventEmitter();
  //产品列表选择改变事件
  productChanges(id:string){
    this.productChange.emit(id);
  }
}
