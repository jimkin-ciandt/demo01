import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService, subjectBaseList} from '../common-control.service';

@Component({
  selector: 'app-subject-base',
  templateUrl: './subject-base.component.html',
  styleUrls: ['./subject-base.component.css']
})
export class SubjectBaseComponent implements OnInit {

  constructor(private service:CommonControlService) { }

  ngOnInit() {
    this.getSubjectBaseList();
  }
  @Input()
  isTrue:boolean=false;
  @Input()
  isMultiple:boolean=false;
  @Input()
  isFirst:boolean=false;
  //已选择的学科ID
  @Input()// 父组件提供数据
  selectedSubject:string = '';
  @Output()
  selectedSubjectChange:EventEmitter<string> = new EventEmitter();
  //学科改变选择改变事件
  subjectBaseChange(data){
    this.selectedSubjectChange.emit(data);
  }
  // 学科列表
  subjectBaseList: subjectBaseList[] = [];
// 获取基础学科
  getSubjectBaseList(){
    this.service.getSubjectBase().subscribe(res=>{
      this.subjectBaseList = res['data'];
    });
  }
}
