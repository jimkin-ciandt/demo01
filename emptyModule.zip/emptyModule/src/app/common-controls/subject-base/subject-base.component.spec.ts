import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubjectBaseComponent } from './subject-base.component';

describe('SubjectBaseComponent', () => {
  let component: SubjectBaseComponent;
  let fixture: ComponentFixture<SubjectBaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubjectBaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubjectBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
