import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService, gradeListInfo} from '../common-control.service';

@Component({
  selector: 'app-school-grade',
  templateUrl: './school-grade.component.html',
  styleUrls: ['./school-grade.component.css']
})
export class SchoolGradeComponent implements OnInit {

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
  }

  @Input()
  isShowAll:boolean = true;
  private _schoolID: string = '';

  //传入的学校id
  @Input()
  set schoolID(schoolID: string) {
    this._schoolID = schoolID;
    this.getGradeList(this.schoolID);
  }

  get schoolID() {
    return this._schoolID;
  }

  private _semesterID: string;
  @Input()
  set semesterID(semesterID: string) {
    this._semesterID = semesterID;
    // if(this._semesterID){
    this.getGradeList(this.schoolID);
    // }
  }

  get semesterID() {
    return this._semesterID;
  }

  //年级列表
  gradeListInfo: gradeListInfo[] = [];

  //获取年级
  getGradeList(id) {
    this.service.getGradeList({
      schoolid: id
    }).subscribe(res => {
      if (res) {
        this.gradeListInfo = res['data'];
        if (this.isShowAll) {
          this.selectedGradeID = '';
          this.selectedGradeIDChange.emit('');
        }
        else {
          if (this.gradeListInfo.length) {
            this.selectedGradeID = this.gradeListInfo[0].id;
            this.selectedGradeIDChange.emit(this.selectedGradeID);
          }
        }
      }

    });
  }

  //已选择的年级
  @Input()
  selectedGradeID: string = '';
  //班级改变发射事件
  @Output()
  selectedGradeIDChange: EventEmitter<string> = new EventEmitter();

  //年级改变事件
  gradeChanges(id) {
    this.selectedGradeIDChange.emit(id);
  }
}
