import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService} from '../common-control.service';

@Component({
  selector: 'app-authorized-strength',
  templateUrl: './authorized-strength.component.html',
  styleUrls: ['./authorized-strength.component.css']
})
export class AuthorizedStrengthComponent implements OnInit {

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
    this.getAuthList();//获取列表
  }

  //已选择的id
  @Input()
  selectedAuthID: string = '';
  @Output()
  selectedAuthIDChange: EventEmitter<string> = new EventEmitter();

  //编制选择改变事件
  authChanges(id) {
    this.selectedAuthIDChange.emit(id);
  }

  //编制列表字段
  authStrength: { code?: string, name?: string, id?: string }[] = [];

  //获取编制列表
  getAuthList() {
    this.service.getAuthStrengthList({
      'schoolid': '',
      'parentcode': 'Establish'
    }).subscribe(res => {
      if (res) {
        this.authStrength = res['data'];
      }
    });
  }
}
