import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthorizedStrengthComponent } from './authorized-strength.component';

describe('AuthorizedStrengthComponent', () => {
  let component: AuthorizedStrengthComponent;
  let fixture: ComponentFixture<AuthorizedStrengthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuthorizedStrengthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthorizedStrengthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
