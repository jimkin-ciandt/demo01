import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService} from '../common-control.service';

@Component({
  selector: 'app-education-level',
  templateUrl: './education-level.component.html',
  styleUrls: ['./education-level.component.css']
})
export class EducationLevelComponent implements OnInit {

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
    this.getEduLevelList();//获取学历列表
  }

  //已选择的学历
  @Input()
  selectedEduID: string = '';
  //学历选择事件
  @Output()
  selectedEduIDChange: EventEmitter<string> = new EventEmitter();

  //选择改变事件
  eduChanges(id) {
    this.selectedEduIDChange.emit(id);
  }

  //选择学历列表
  eduLevelList: {
    id?: string
    name?: string
  }[] = [];

  //获取列表
  getEduLevelList() {
    this.service.getEduLevelList({
      'parentcode': 'educationallevel'
    }).subscribe(res => {
      if (res) {
         this.eduLevelList=res['data'];
      }
    });
  }
}
