import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';


@Component({
  selector: 'app-monthweek-select',
  templateUrl: './monthweek-select.component.html',
  styleUrls: ['./monthweek-select.component.css']
})
export class MonthweekSelectComponent implements OnInit {
  isSelect : string;
  noSelect :string;
  constructor() {

  }
  ngOnInit() {

  }

  @Input()
  selectWhich:number=1;
  //切换改变
  @Output()
  selectWhichChange:EventEmitter<number>=new EventEmitter();
  onSelect(data){
    this.selectWhich=data;
    this.selectWhichChange.emit(data);
  }
}
