import {Component, EventEmitter, Input, OnChanges, OnInit, Output} from '@angular/core';
import {CommonControlService} from '../common-control.service'
@Component({
  selector: 'app-all-grade',
  templateUrl: './all-grade.component.html',
  styleUrls: ['./all-grade.component.css']
})
export class AllGradeComponent implements OnInit {
  gradeList:any;
  schoolID:string;
  postData={
    schoolid:""
  };
  constructor(private service:CommonControlService) {

  }
  ngOnInit() {
    this.postData.schoolid =this.selectedSchoolId
  }
  @Input()
  isFirst:boolean=false;
  _selectedSchoolId:string='';

  @Input()
  set selectedSchoolId(selectedSchoolId:string){
    this._selectedSchoolId = selectedSchoolId;
    this.postData.schoolid = selectedSchoolId;
    this.GetGradeBySchool(this.postData);
  }
  get selectedSchoolId(){
    return this._selectedSchoolId;
  }

  @Output()
  selectedSchoolIdChange: EventEmitter<any> = new EventEmitter();

  @Input()
  selectedGradeId:string="";

  //年级下拉框发生改变
  @Output()
  selectedGradeIdChange: EventEmitter<string> = new EventEmitter();
  //年级id发生改变
  gradeChange(data){
    this.selectedGradeIdChange.emit(data);
  }
  //根据学校id去获取年级
  GetGradeBySchool(data){
    this.service.GetGradeBySchool(data).subscribe(res=>{
       this.selectedGradeId='';
      this.selectedGradeIdChange.emit('');
     this.gradeList = res.data;
      //this.selectedGradeIdChange.emit(this.gradeList)
    })
  }
}
