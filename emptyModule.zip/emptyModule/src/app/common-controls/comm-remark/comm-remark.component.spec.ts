import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommRemarkComponent } from './comm-remark.component';

describe('CommRemarkComponent', () => {
  let component: CommRemarkComponent;
  let fixture: ComponentFixture<CommRemarkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommRemarkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommRemarkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
