import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-comm-remark',
  templateUrl: './comm-remark.component.html',
  styleUrls: ['./comm-remark.component.css']
})
export class CommRemarkComponent implements OnInit {

  constructor() { }
 
  ngOnInit() {
  }
  @Input()
  title: string ;
  @Input()
  remark: string ;
}
