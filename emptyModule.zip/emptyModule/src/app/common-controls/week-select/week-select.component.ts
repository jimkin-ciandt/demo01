
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonControlService } from '../common-control.service';
import { callbackify } from 'util';
@Component({
  selector: 'app-week-select',
  templateUrl: './week-select.component.html',
  styleUrls: ['./week-select.component.css']
})
export class WeekSelectComponent implements OnInit {
  date: any;
  week: any;
  dataModal: number;
  monthNum: number;
  weekNum: number;
  @Input()
  schoolId: string;
  _schoolId: string;
  semesterData: any[] = [];//全部学期的数据
  weekItemChoseIndex: number;
  monthItemChoseIndex: string;
  annListLength: number;
  session: any[] = [];
  sessionId: number;
  monent_time: any;
  annalyList: any[] = [];
  getAnallyData: any;
  day_table_up: any[] = [];
  day_table_now: any[] = [];
  day_table_after: any[] = [];
  weekData: any[] = [];
  monthData: any[] = [];
  dat_table_item = {
    num: 0,
  };
  isShow: number = 2;
  startTime: string;
  endTime: string;
  sendData: any;
  constructor(private service: CommonControlService) {
  }
  sessionChange(e) {
    
  }
    //学期改变初始化
    initSem(e) {
      for (let i = 0; i < this.semesterData.length; i++) {
        if (
          this.semesterData[i].bayearid == e &&
          this.semesterData[i].iscurrent == 1
        ) {
          //当前学期的话选择的就是当前的学期传入的就是开始时间到现在的时间段
          this.startTime = this.semesterData[i].startdate;
          var month = new Date(this.startTime).getMonth() + 1;
          this.monent_time = new Date(this.startTime).getFullYear() + "-" + month;
          this.endTime = this.semesterData[i].enddate;
          var date = new Date();
          var year = date.getFullYear();
          var month = date.getMonth() + 1;
          var month_string = month < 10 ? "0" + month : month;
          var day = date.getDate();
          var day_string = day < 10 ? "0" + day : day;
          var endTime =
            year + "-" + month_string + "-" + day_string + "T00:00:00";
          this.initWeek(this.startTime, this.endTime);
       
        } else if (this.semesterData[i].bayearid == e) {
          //选择以前的学期传入的时间段就是从接口上拿到的开始时间和结束时间
          this.startTime = this.semesterData[i].startdate;
          var month = new Date(this.startTime).getMonth() + 1;
          this.monent_time = new Date(this.startTime).getFullYear() + "-" + month;
          this.endTime = this.semesterData[i].enddate;
          this.initWeek(this.startTime, this.endTime);
        }
      }
    }
  //当学校发生变化时时间控件日期发生改变
  semeterChange(e) {
    this.semesterData = [];
    this.semesterData = e.data;
    this.startTime = e.data[e.index].startdate;
    var month = new Date(this.startTime).getMonth() + 1;
    this.monent_time = new Date(this.startTime).getFullYear() + '-' + month;
    this.endTime = e.data[e.index].enddate;
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var month_string = month < 10 ? "0" + month : month;
    var day = date.getDate();
    var day_string = day < 10 ? "0" + day : day;
    var endTime = year + "-" + month_string + "-" + day_string + "T00:00:00";
    var endT = year + "-" + month_string + "-" + day_string;
    this.initWeek(this.startTime, this.endTime);
    var startT = this.startTime.indexOf("T");
    var startTime = this.startTime.slice(0, startT);
    //this.initSem(e);
  }
  ngOnInit() {
    this.sessionId = 0;
    this.getAnallyData = {
      'schoolid': '',
      'pager': {
        'pager': false,
        'pageIndex': 1,
        'pageSize': 0
      },
      'id': ''
    };
    this.sendData = {
      "month": "",
      "weekNum": "",
      "dataModel": "",
      "startDate": "",
      "endDate": "",
      "session": ""
    }
  }

  //学期的改变
  next_session() {
    this.annalyList = [];
    if (this.sessionId != this.annListLength) {
      this.sessionId++;
    }
  };

  //学期的点击
  up_session() {
    if (this.sessionId != 0) {
      this.sessionId--;
    }
  };

  //获取某天是星期几
  getDayInWeek(time, callback) { //星期天返回的是0;其他星期几就是返回几
    var week = new Date(time).getDay();
    callback(week);
  };

  //获取某个月有几天
  getDayByMonth(year, month, callback) {
    var day = new Date(year, month, 0);
    callback(day.getDate());
  };

  //将时间戳转化为日期格式
  add0(m) {
    return m < 10 ? '0' + m : m;
  }

  //格式化代码
  format(shijianchuo, callback) {
    //shijianchuo是整数，否则要parseInt转换
    var time = new Date(shijianchuo);
    var y = time.getFullYear();
    var m = time.getMonth() + 1;
    var d = time.getDate();
    var h = time.getHours();
    var mm = time.getMinutes();
    var s = time.getSeconds();
    var time_up = {
      date: '',
      year: 0,
      month: '',
      day: '',
      timeFormat: ''
    };
    time_up.date = y + '-' + this.add0(m) + '-' + this.add0(d);
    time_up.year = y;
    time_up.month = this.add0(m);
    time_up.day = this.add0(d);
    time_up.timeFormat = shijianchuo;
    callback(time_up);
  }

  //计算日期控件上面周的
  initWeek(start, end) {
    let timeForMat = [];
    let allNeedData = [];
    let needDate = [];
    let timeForMat1 = [];
    let startTime = Date.parse(start);
    let endTime = Date.parse(end);
    let num = 0;
    for (let i = startTime; i <= endTime; i = i + 86400000) {
      //先把开始时间和结束时间转化成时间轴来吧时间换算成我所需的参数
      let date_item = {
        date: "",
        year: "",
        month: "",
        day: "",
        index: 0,
        num: num++
      };
      this.format(i, res => {
        date_item.date = res.date;
        date_item.year = res.year;
        date_item.month = res.month;
        date_item.day = res.day;
        date_item.index = i;
      });
      timeForMat.push(date_item); //从开始时间和结束时间拼装成的数据
      timeForMat1.push(date_item);
    }
    this.getDayInWeek(start, res => {
      //获取开始时间是星期几
      let needDate_item = {
        monthIndex: "",
        weekIndex: 0,
        startTime: "",
        endTime: "",
        start:"",
        end:""
      };
      this.getDayInWeek(end, response => {
        //获取结束时间是星期几
        let needDate_item = {
          monthIndex: "",
          weekIndex: 0,
          startTime: "",
          endTime: "",
          start:"",
          end:""
        };
        let now_index = 0; //记录要每个周加1
        let firstData_all = [];
        let firstData: any;
        let needData_sure = [];
        let top_sliceData = [];
        let endWeekData = [];
        if (res == 0) {
          //代表星期0是从开始时间开始算
          needDate_item.monthIndex = timeForMat1[0].month;
          needDate_item.weekIndex = 1;
          needDate_item.startTime = timeForMat1[0].date;
          needDate_item.endTime = timeForMat1[0].date;
          needDate_item.start = new Date(timeForMat1[0].date).getTime()+"";
          needDate_item.end = new Date(timeForMat1[0].date).getTime()+"";
          firstData = timeForMat1[1];
          top_sliceData = timeForMat.slice(1, timeForMat.length);
        } else {
          firstData = timeForMat1[8 - res]; //从开始时间的第二个星期的星期一开始算
          needDate_item.monthIndex = timeForMat1[0].month;
          needDate_item.weekIndex = timeForMat1[0].num;
          needDate_item.startTime = timeForMat1[0].date;
          needDate_item.endTime = timeForMat1[7 - res].date;
          needDate_item.start =new Date(timeForMat1[0].date).getTime()+"";
          needDate_item.end = new Date(timeForMat1[7 - res].date).getTime()+"";
          top_sliceData = timeForMat.slice(8 - res, timeForMat.length);
          let needDate_items = {
            monthIndex: timeForMat[0].month,
            weekIndex: 1,
            startTime: timeForMat[0].date,
            endTime: timeForMat[8 - res].date,
            start:new Date(timeForMat[0].date).getTime(),
            end:new Date(timeForMat[8 - res].date).getTime(),
          };
          needDate.push(needDate_items);
        }
        if (response == 0) {
          //结束时间的最后一天是星期天
          needData_sure = top_sliceData;
          top_sliceData = [];
        } else {
          needData_sure = top_sliceData.splice(
            0,
            top_sliceData.length - response
          ); //needData_sure数组代表的是截到最后一个星期前的数据
        }
        for (var i = 0; i < needData_sure.length - 1; i++) {
          let needDate_items = {
            monthIndex: "",
            weekIndex: 0,
            startTime: "",
            endTime: "",
            start:"",
            end:""
          };
          if (now_index === 0 || now_index % 7 === 0) {
            needDate_items.monthIndex = needData_sure[i].month;
            needDate_items.weekIndex = now_index;
            num = now_index + 6;
            needDate_items.startTime = needData_sure[now_index].date;
            needDate_items.endTime = needData_sure[num].date;
            needDate_items.start = new Date(needData_sure[now_index].date).getTime()+"";
            needDate_items.end =new Date(needData_sure[num].date).getTime()+"";
            let arr = [needDate_items];
            needDate.push(...arr);
          }
          now_index++;
        }
        let needDate_item1 = {
          monthIndex: "",
          weekIndex: 0,
          startTime: "",
          endTime: "",
          start:"",
          end:""
        };
        if (top_sliceData.length == 0) {
        } else {
          needDate_item1.monthIndex = top_sliceData[0].month;
          needDate_item1.weekIndex = 0;
          needDate_item1.startTime = top_sliceData[0].date;
          needDate_item1.endTime = top_sliceData[top_sliceData.length - 1].date;
          needDate_item1.start =new Date(top_sliceData[0].date).getTime()+"";
          needDate_item1.end = new Date(top_sliceData[top_sliceData.length - 1].date).getTime()+"";
          needDate.push(needDate_item1);
        }
        let needData_item = {
          monthIndex: "",
          weekArr: []
        };
        let needData_all = [];
        for (let j = 0; j < needDate.length; j++) {
          needDate[j].weekNum = j + 1;
          if (j != needDate.length - 1) {
            //排除最后一项
            if (
              needDate[j].monthIndex == needDate[j + 1].monthIndex &&
              j != needDate.length - 2
            ) {
              needData_item.monthIndex = needDate[j].monthIndex;
              needData_item.weekArr.push(needDate[j]);
            } else if (j == needDate.length - 2) {
              needData_item.monthIndex = needDate[j].monthIndex;
              needData_item.weekArr.push(needDate[j]);
              needData_all.push(JSON.parse(JSON.stringify(needData_item)));
              needData_item.monthIndex = "";
              needData_item.weekArr = [];
            } else {
              needData_item.weekArr.push(needDate[j]);
              needData_all.push(JSON.parse(JSON.stringify(needData_item)));
              needData_item.monthIndex = "";
              needData_item.weekArr = [];
            }
          } else {
            let num1 = j - 1;
            if (needDate[j].monthIndex == needDate[num1].monthIndex) {
              needData_all[needData_all.length - 1].weekArr.push(needDate[j]);
            } else {
              needData_item.monthIndex = needDate[j].monthIndex;
              needData_item.weekArr.push(needDate[j]);
              needData_all.push(JSON.parse(JSON.stringify(needData_item)));
            }
          }
        }
        let nowDate = new Date();
        let nowMonth = nowDate.getMonth() + 1;
        let nowTime = nowDate.getTime();
        for(let i=0;i<needData_all.length;i++){
          if(nowMonth == parseInt(needData_all[i].monthIndex)){
              for(let s =0;s<needData_all[i].weekArr.length;s++){
                if(nowTime>=needData_all[i].weekArr[s].start && nowTime<=needData_all[i].weekArr[s].end){
                  this.weekItemChoseIndex = needData_all[i].weekArr[s].weekNum;
                  this.date = needData_all[i].weekArr[s].startTime + '至' + needData_all[i].weekArr[s].endTime;
                  this.sendData.startDate = needData_all[i].weekArr[s].startTime;
                  this.sendData.endDate = needData_all[i].weekArr[s].endTime;
                }
              }
          } 
        }



       
        this.weekData = needData_all;
        this.sendData.month = this.weekData[0].monthIndex;
        this.sendData.weekNum = 1;
        this.sendData.dataModel =3;
      
        this.sendData.session = this.sessionId;
        this.arrDatyTypeChange.emit(this.sendData);
        this.weekData = needData_all;
      });
    });
  }











  //计算日期控件上面周的
  // initWeek(start, end) {
  //   let timeForMat = [];
  //   let allNeedData = [];
  //   let needDate = [];
  //   let timeForMat1 = [];
  //   let startTime = Date.parse(start);
  //   let endTime = Date.parse(end);
  //   let num = 0;
  //   for (let i = startTime; i <= endTime; i = i + 86400000) {//先把开始时间和结束时间转化成时间轴来吧时间换算成我所需的参数
  //     let date_item = {
  //       date: '',
  //       year: '',
  //       month: '',
  //       day: '',
  //       index: 0,
  //       num: num++
  //     };
  //     this.format(i, res => {
  //       date_item.date = res.date;
  //       date_item.year = res.year;
  //       date_item.month = res.month;
  //       date_item.day = res.day;
  //       date_item.index = i;
  //     });
  //     timeForMat.push(date_item);//从开始时间和结束时间拼装成的数据
  //     timeForMat1.push(date_item);
  //   }
  //   this.getDayInWeek(start, res => {//获取开始时间是星期几
  //     let needDate_item = {
  //       monthIndex: '',
  //       weekIndex: 0,
  //       startTime: '',
  //       endTime: '',
  //       start:"",
  //       end:""
  //     };
  //     this.getDayInWeek(end, response => {//获取结束时间是星期几
  //       let needDate_item = {
  //         monthIndex: '',
  //         weekIndex: 0,
  //         startTime: '',
  //         endTime: '',
  //         start:'',
  //         end:""
  //       };
  //       let now_index = 0; //记录要每个周加1
  //       let firstData_all = [];
  //       let firstData: any;
  //       let needData_sure = [];
  //       let top_sliceData = [];
  //       let endWeekData = [];
  //       if (res == 0) {//代表星期0是从开始时间开始算
  //         needDate_item.monthIndex = timeForMat1[0].month;
  //         needDate_item.weekIndex = 1;
  //         needDate_item.startTime = timeForMat1[0].date;
  //         needDate_item.endTime = timeForMat1[0].date;
  //         needDate_item.start = new Date(timeForMat1[0].date).getTime()+"";
  //         needDate_item.end = new Date(timeForMat1[0].date).getTime()+"";
  //         firstData = timeForMat1[1];
  //         top_sliceData = timeForMat.slice(1, timeForMat.length)
  //       } else {
  //         firstData = timeForMat1[8 - res];//从开始时间的第二个星期的星期一开始算
  //         needDate_item.monthIndex = timeForMat1[0].month;
  //         needDate_item.weekIndex = timeForMat1[0].num;
  //         needDate_item.startTime = timeForMat1[0].date;
  //         needDate_item.endTime = timeForMat1[7 - res].date;
  //         needDate_item.start = new Date(timeForMat1[0].date).getTime()+"";
  //         needDate_item.end = new Date(timeForMat1[7 - res].date).getTime()+"";
  //         top_sliceData = timeForMat.slice(8 - res, timeForMat.length)
  //         let needDate_items = {
  //           monthIndex: timeForMat[0].month,
  //           weekIndex: 1,
  //           startTime: timeForMat[0].date,
  //           endTime: timeForMat[8 - res].date,
  //           start:new Date(timeForMat[0].date).getTime()+"",
  //           end:new Date(timeForMat[8 - res].date).getTime()+""
  //         };
  //         needDate.push(needDate_items)
  //       }
  //       if (response == 0) {//结束时间的最后一天是星期天
  //         needData_sure = top_sliceData;
  //         top_sliceData = [];
  //       } else {
  //         needData_sure = top_sliceData.splice(0, top_sliceData.length - response);//needData_sure数组代表的是截到最后一个星期前的数据
  //       }
  //       for (var i = 0; i < needData_sure.length - 1; i++) {
  //         let needDate_items = {
  //           monthIndex: '',
  //           weekIndex: 0,
  //           startTime: '',
  //           endTime: '',
  //           start:"",
  //           end:""
  //         };
  //         if (now_index === 0 || now_index % 7 === 0) {
  //           needDate_items.monthIndex = needData_sure[i].month;
  //           needDate_items.weekIndex = now_index;
  //           num = now_index + 6;
  //           needDate_items.startTime = needData_sure[now_index].date;
  //           needDate_items.endTime = needData_sure[num].date;
  //           needDate_items.start = new Date(needData_sure[now_index].date).getTime()+"";
  //           needDate_items.end =  new Date(needData_sure[num].date).getTime()+"";
  //           let arr = [needDate_items];
  //           needDate.push(...arr);
  //         }
  //         now_index++;
  //       }
  //       let needDate_item1 = {
  //         monthIndex: '',
  //         weekIndex: 0,
  //         startTime: '',
  //         endTime: '',
  //         start:"",
  //         end:""
  //       };
  //       if (top_sliceData.length == 0) {

  //       } else {
  //         needDate_item1.monthIndex = top_sliceData[0].month;
  //         needDate_item1.weekIndex = 0;
  //         needDate_item1.startTime = top_sliceData[0].date;
  //         needDate_item1.endTime = top_sliceData[top_sliceData.length - 1].date;
  //         needDate_item1.start = new Date(top_sliceData[0].date).getTime()+"";
  //         needDate_item1.end = new Date(top_sliceData[top_sliceData.length - 1].date).getTime()+"";
  //         needDate.push(needDate_item1);
  //       }
  //       let needData_item = {
  //         monthIndex: '',
  //         weekArr: []
  //       };
  //       let needData_all = [];
  //       for (let j = 0; j < needDate.length; j++) {
  //         needDate[j].weekNum = j + 1;
  //         if (j != needDate.length - 1) {//排除最后一项
  //           if (needDate[j].monthIndex == needDate[j + 1].monthIndex && j != needDate.length - 2) {
  //             needData_item.monthIndex = needDate[j].monthIndex;
  //             needData_item.weekArr.push(needDate[j]);
  //           } else if (j == needDate.length - 2) {
  //             needData_item.monthIndex = needDate[j].monthIndex;
  //             needData_item.weekArr.push(needDate[j]);
  //             needData_all.push(JSON.parse(JSON.stringify(needData_item)));
  //             needData_item.monthIndex = '';
  //             needData_item.weekArr = [];
  //           } else {
  //             needData_item.weekArr.push(needDate[j]);
  //             needData_all.push(JSON.parse(JSON.stringify(needData_item)));
  //             needData_item.monthIndex = '';
  //             needData_item.weekArr = [];
  //           }
  //         } else {
  //           let num1 = j - 1;
  //           if (needDate[j].monthIndex == needDate[num1].monthIndex) {
  //             needData_all[needData_all.length - 1].weekArr.push(needDate[j]);
  //           } else {
  //             needData_item.monthIndex = needDate[j].monthIndex;
  //             needData_item.weekArr.push(needDate[j]);
  //             needData_all.push(JSON.parse(JSON.stringify(needData_item)));
  //           }
  //         }
  //       }
  //       debugger
  //       let nowDate = new Date();
  //       let nowMonth = nowDate.getMonth() + 1;
  //       let nowTime = nowDate.getTime();
  //       for(let i=0;i<needData_all.length;i++){
  //         if(nowMonth == parseInt(needData_all[i].monthIndex)){
  //             for(let s =0;s<needData_all[i].weekArr.length;s++){
  //               if(nowTime>=needData_all[i].weekArr[s].start && nowTime<=needData_all[i].weekArr[s].end){
  //                 this.weekItemChoseIndex = needData_all[i].weekArr[s].weekNum;
  //                 this.date = needData_all[i].weekArr[s].startTime + '至' + needData_all[i].weekArr[s].endTime;
  //                 this.sendData.startDate = needData_all[i].weekArr[s].startTime;
  //                 this.sendData.endDate = needData_all[i].weekArr[s].endTime;;
  //               }
  //             }
  //         } 
  //       }



       
  //       this.weekData = needData_all;
  //       this.sendData.month = this.weekData[0].monthIndex;
  //       this.sendData.weekNum = 1;
  //       this.sendData.dataModel =3;
      
  //       this.sendData.session = this.sessionId;
  //       this.arrDatyTypeChange.emit(this.sendData);
  //     });
  //   });

  // };



  //时间发生改变
  onValueChange(e) {
  }




  //模式发生改变
  onModeChange(e) {

  }

  //旁边月周日大类的点击
  choseItem(number) {
    this.isShow = number;
    this.dateModelChange.emit(number);
  }

  //周的点击
  weekClick(el) {
    this.weekItemChoseIndex = el.weekNum;
    this.date = el.startTime + '至' + el.endTime;
    this.sendData.month = "";
    this.sendData.weekNum = el.weekNum;
    this.sendData.dataModel = 3;
    this.sendData.startDate = el.startTime;
    this.sendData.endDate = el.endTime;
    this.sendData.session = this.sessionId;
    this.arrDatyTypeChange.emit(this.sendData);
  }
  //月的点击
  monthClick(el) {
    this.monthItemChoseIndex = el.month;
    this.date = el.startTime + '至' + el.endTime;
    this.sendData.month = parseInt(el.month);
    this.sendData.weekNum = 0;
    this.sendData.dataModel = 2;
    this.sendData.startDate = "";
    this.sendData.endDate = "";
    this.sendData.session = this.sessionId;
    this.arrDatyTypeChange.emit(this.sendData);
  }
  //每个时间点的点击
  item_dayClick(e) {
    let endTime = "";
    let arrData = [];
    let index = 0;
    for (let i = 0; i < this.day_table_now.length; i++) {
      this.day_table_now[i].isClick = false;
    }
    this.getDayInWeek(e.date, res => {
      for (let i = 0; i < this.day_table_now.length; i++) {
        if (e.index == this.day_table_now[i].index) {
          index = i;
          break;
        }
      }
      for (var i = 0; i <= 7 - res; i++) {
        this.day_table_now[index + i].isClick = true;
        if (i == 7 - res) {
          endTime = this.day_table_now[i].date;
        }
      }
      var startTime = this.day_table_now[0].date;
      this.date = startTime + "至" + endTime;
      this.sendData.month = 0;
      this.sendData.weekNum = 0;
      this.sendData.dataModel = 4;
      this.sendData.startDate = startTime;
      this.sendData.endDate = endTime;
      this.sendData.session = this.sessionId;
      this.arrDatyTypeChange.emit(this.sendData);
    });
  }

  // @Input()
  // schoolID:string
  //监听上面时间发生变化
  private _dateTime: any;
  @Input()
  set arrDatyType(arrDatyType: any) {
    this._dateTime = arrDatyType
  }
  get arrDatyType() {
    return this._dateTime
  }
  @Output()
  arrDatyTypeChange: EventEmitter<string> = new EventEmitter();

  dateChange(e) {
    this.arrDatyTypeChange.emit(e);
  }
  //dateModel
  @Output()
  dateModelChange: EventEmitter<number> = new EventEmitter();
}
