import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {SchoolListCtrComponent} from './school-list-ctr/school-list-ctr.component';
import {NgZorroAntdModule} from 'ng-zorro-antd';
import {CommonControlService} from './common-control.service';
import {FormsModule} from '@angular/forms';
import {PlaceSelectedComponent} from './place-selected/place-selected.component';
import {GradeLevelComponent} from './grade-level/grade-level.component';
import {GradeBaseComponent} from './grade-base/grade-base.component';
import {SubjectBaseComponent} from './subject-base/subject-base.component';
import {BaiduMapComponent} from './baidu-map/baidu-map.component';
import {MonthweekSelectComponent} from './monthweek-select/monthweek-select.component';
import {UploadFileComponent} from './upload-file/upload-file.component';
import {SchoolSemesterComponent} from './school-semester/school-semester.component';
import {SchoolGradeComponent} from './school-grade/school-grade.component';
import {SchoolClassesComponent} from './school-classes/school-classes.component';
import {AllGradeComponent} from './all-grade/all-grade.component';
import {DataTimePickComponent} from './data-time-pick/data-time-pick.component';
import {SchoolConditionsComponent} from './school-conditions/school-conditions.component';
import {TableHeaderFixedDirective} from './table-header-fixed/table-header-fixed.directive';
import {SchoolsByPlacesComponent} from './schools-by-places/schools-by-places.component';
import {AllPlaceComponent} from './all-place/all-place.component';
import {AllProductsComponent} from './all-products/all-products.component';
import {DataTimePickByUseComponent} from './data-time-pick-by-use/data-time-pick-by-use.component';
import {AllTeacherComponent} from './all-teacher/all-teacher.component';
import {AgeSelectComponent} from './age-select/age-select.component';
import {SubjectBySchoolComponent} from './subject-by-school/subject-by-school.component';
import {CascaderPlaceComponent} from './cascader-place/cascader-place.component';
import {InstrumentListComponent} from './instrument-list/instrument-list.component';
import {AllExperimentroomComponent} from './all-experimentroom/all-experimentroom.component';
import {WeekSelectComponent} from './week-select/week-select.component';
import {EducationLevelComponent} from './education-level/education-level.component';
import {AuthorizedStrengthComponent} from './authorized-strength/authorized-strength.component';
import {PositionTypeComponent} from './position-type/position-type.component';
import {PoliticsStatusComponent} from './politics-status/politics-status.component';
import {TypesComponent} from './asset-types/asset-types.component';
import {CapitalSourceComponent} from './capital-source/capital-source.component';
import {SchoolClassroomComponent} from './school-classroom/school-classroom.component';
import { DangerousListComponent } from './dangerous-list/dangerous-list.component';
import { AllGradeBaseComponent } from './all-grade-base/all-grade-base.component';
import { MultiroomBaseComponent } from './multiroom-base/multiroom-base.component';
import { MultipleSelectSchoolComponent } from './multiple-select-school/multiple-select-school.component';
import { CommRemarkComponent } from './comm-remark/comm-remark.component';
import { SchoolClaaaSelectComponent } from './school-claaa-select/school-claaa-select.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgZorroAntdModule
  ],
  exports: [
    NgZorroAntdModule,
    FormsModule,
    SchoolListCtrComponent,
    GradeLevelComponent,
    PlaceSelectedComponent,
    GradeBaseComponent,
    SubjectBaseComponent,
    BaiduMapComponent,
    MonthweekSelectComponent,
    UploadFileComponent,
    SchoolSemesterComponent,
    SchoolGradeComponent,
    SchoolClassesComponent,
    AllGradeComponent,
    DataTimePickComponent,
    SchoolConditionsComponent,
    TableHeaderFixedDirective,
    SchoolsByPlacesComponent,
    AllPlaceComponent,
    AllProductsComponent,
    DataTimePickByUseComponent,
    AllTeacherComponent,
    AgeSelectComponent,
    SubjectBySchoolComponent,
    CascaderPlaceComponent,
    InstrumentListComponent,
    AllExperimentroomComponent,
    WeekSelectComponent,
    AuthorizedStrengthComponent,
    EducationLevelComponent,
    PoliticsStatusComponent,
    PositionTypeComponent,
    TypesComponent,
    CapitalSourceComponent,
    SchoolClassroomComponent,
    DangerousListComponent,
    AllGradeBaseComponent,
    MultiroomBaseComponent,
    MultipleSelectSchoolComponent,
    CommRemarkComponent,
    SchoolClaaaSelectComponent
  ],
  declarations: [
    SchoolListCtrComponent,
    PlaceSelectedComponent,
    GradeLevelComponent,
    GradeBaseComponent,
    SubjectBaseComponent,
    BaiduMapComponent,
    MonthweekSelectComponent,
    UploadFileComponent,
    SchoolSemesterComponent,
    SchoolGradeComponent,
    SchoolClassesComponent,
    AllGradeComponent,
    DataTimePickComponent,
    SchoolConditionsComponent,
    TableHeaderFixedDirective,
    SchoolsByPlacesComponent,
    AllPlaceComponent,
    AllProductsComponent,
    DataTimePickByUseComponent,
    AllTeacherComponent,
    AgeSelectComponent,
    SubjectBySchoolComponent,
    CascaderPlaceComponent,
    InstrumentListComponent,
    AllExperimentroomComponent,
    WeekSelectComponent,
    EducationLevelComponent,
    AuthorizedStrengthComponent,
    PositionTypeComponent,
    PoliticsStatusComponent,
    TypesComponent,
    CapitalSourceComponent,
    SchoolClassroomComponent,
    DangerousListComponent,
    AllGradeBaseComponent,
    MultiroomBaseComponent,
    MultipleSelectSchoolComponent,
    CommRemarkComponent,
    SchoolClaaaSelectComponent,
  ],
  providers: [CommonControlService],
  entryComponents: [AllPlaceComponent]
})
export class CommonControlsModule {
}
