import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {CommonControlService} from '../common-control.service';


@Component({
  selector: 'app-age-select',
  templateUrl: './age-select.component.html',
  styleUrls: ['./age-select.component.css']
})
export class AgeSelectComponent implements OnInit {

  ageList:any[] =[];

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
    this.getAgeRangeList();//获取年龄段
  }

  @Input()
  selectedage: number = -1;
  @Output()
  selectedageChange: EventEmitter<number> = new EventEmitter();
  @Output()
  ageChanges: EventEmitter<any> = new EventEmitter();

  ageChange(data) {
    this.selectedageChange.emit(data);
    if(data===-1){
      this.ageChanges.emit({
        startAge:-1,
        endAge:-1,
        id:-1
      })
    }
    else{
      for (let i = 0; i < this.ageList.length; i++) {
        if (this.ageList[i].id === data) {
          this.ageChanges.emit(this.ageList[i]);
          return;
        }
      }
    }

  }

  //获取年龄段信息
  getAgeRangeList() {
    this.service.getAgeRangeList().subscribe(res => {
      if (res) {
        this.ageList = res['data'];
      }
    });
  }



}
