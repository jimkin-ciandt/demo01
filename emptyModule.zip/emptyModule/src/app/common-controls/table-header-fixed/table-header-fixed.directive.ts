import {AfterViewInit, Directive, ElementRef, OnDestroy} from '@angular/core';

@Directive({
  selector: '[tableHeaderFixed]'
})
export class TableHeaderFixedDirective implements AfterViewInit, OnDestroy {

  constructor(private element: ElementRef) {
  }

//页面初始化完成后监听
  ngAfterViewInit(): void {
    setTimeout(() => {
      this.watchScoll();//开始监听
    }, 1000);
  }


  //滚动监听处理函数
  watchScroll: any;
  //滚动主DOM
  mainScrollElement: HTMLElement;

  //监听滚动
  watchScoll() {
    this.mainScrollElement = document.getElementById('mainFrameWrap');
    //获取需要滚动的table表头
    let element = (<HTMLElement>this.element.nativeElement);
    //获取当前表头距离浏览器顶部高度
    let tableTop = element.getBoundingClientRect().top;
    let widthList = [];
    let thList: HTMLCollection = (<HTMLElement>this.element.nativeElement).children;
    //记录表头每个单元格宽度
    for (let i = 0; i < thList.length; i++) {
      widthList.push((<HTMLElement>thList[i]).getBoundingClientRect().width);
    }
    //滚动监听主方法
    this.watchScroll = () => {
      if (this.mainScrollElement.scrollTop >= tableTop && element.className.indexOf('fixedTableHeader') === -1) {
        element.className += ' fixedTableHeader';
        for (let i = 0; i < element.children.length; i++) {
          (<HTMLElement>element.children[i]).style.width = widthList[i] + 'px';
        }
      }
      else if (this.mainScrollElement.scrollTop < tableTop) {
        element.className = element.className.replace('fixedTableHeader', '');
      }
    };
    //开始滚动监听
    if (element && this.mainScrollElement) {
      this.mainScrollElement.addEventListener('scroll', this.watchScroll);
    }
  }

  ngOnDestroy(): void {
    //销毁监听
    if (this.mainScrollElement && this.watchScoll) {
      this.mainScrollElement.removeEventListener('scroll', this.watchScoll);
    }
  }
}
