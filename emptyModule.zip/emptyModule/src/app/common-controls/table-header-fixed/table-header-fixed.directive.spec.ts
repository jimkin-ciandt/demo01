import { TableHeaderFixedDirective } from './table-header-fixed.directive';

describe('TableHeaderFixedDirective', () => {
  it('should create an instance', () => {
    const directive = new TableHeaderFixedDirective();
    expect(directive).toBeTruthy();
  });
});
