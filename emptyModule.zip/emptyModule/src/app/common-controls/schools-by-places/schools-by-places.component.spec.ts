import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SchoolsByPlacesComponent } from './schools-by-places.component';

describe('SchoolsByPlacesComponent', () => {
  let component: SchoolsByPlacesComponent;
  let fixture: ComponentFixture<SchoolsByPlacesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SchoolsByPlacesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SchoolsByPlacesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
