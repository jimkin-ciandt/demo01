import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService, placeSchoolInfo} from '../common-control.service';

@Component({
  selector: 'app-schools-by-places',
  templateUrl: './schools-by-places.component.html',
  styleUrls: ['./schools-by-places.component.css']
})
export class SchoolsByPlacesComponent implements OnInit {

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
  }

  _placesIDs: string[] = [];

  //地区id
  @Input()
  set placesIDs(placesIDs: string[]) {
    this._placesIDs = placesIDs;
    this.getSchoolByPlace();
  }

  get placesIDs() {
    return this._placesIDs;
  }

  //学校信息
  schools: placeSchoolInfo[] = [];

  //通过地区id获取学校
  getSchoolByPlace() {
    this.service.getSchoolInfoByCounty({
      countyids: [...this.placesIDs]
    }).subscribe(res => {
      if (res) {
        this.schools = res['data'];
        if (this.isRefresh) {
          this.selectedSchool = '';
        }
        if(this.isShow){// 模态框去掉全部学校
          if(this.selectedSchool == ''){
            this.selectedSchool = this.schools[0].id;
            this.selectedSchoolChange.emit(this.schools[0].id);
          }
        }
      }
      //默认显示第一个学校
      if (this.schools.length) {
        if (this.isFirst) {
          this.selectedSchool = this.schools[0].id;
          this.selectedSchoolChange.emit(this.schools[0].id);
        }
        else {
        }
      }
    });
  }
  @Input()
  isShow:boolean = false;
  @Input()
  isRefresh: boolean = true;
  @Input()
  isFirst: boolean = false;
  //已选择的学校
  @Input()
  selectedSchool: string = '';
  //学校改变发射id
  @Output()
  selectedSchoolChange: EventEmitter<string> = new EventEmitter();

  //选择学校改变
  selectedChange(id: string) {
    this.selectedSchoolChange.emit(id);
  }
}
