import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubjectBySchoolComponent } from './subject-by-school.component';

describe('SubjectBySchoolComponent', () => {
  let component: SubjectBySchoolComponent;
  let fixture: ComponentFixture<SubjectBySchoolComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubjectBySchoolComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubjectBySchoolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
