import { Component, OnInit, Input, Output ,EventEmitter } from '@angular/core';
import {CommonControlService} from '../common-control.service';

@Component({
  selector: 'app-subject-by-school',
  templateUrl: './subject-by-school.component.html',
  styleUrls: ['./subject-by-school.component.css']
})
export class SubjectBySchoolComponent implements OnInit {

  constructor(private service:CommonControlService) { }
  getData =  {
    "schoolid": ""
  }
  subjectBaseList:any[] = []
  ngOnInit() {
  }
  _selectSchoolId:string;
  //学校id
  @Input()
  set selectSchoolId(selectSchoolId:string){
    this._selectSchoolId=selectSchoolId;
    this.getData.schoolid = selectSchoolId;
    this.GetCourseList();
  }
  get placesIDs(){
  return this._selectSchoolId
  }

  @Input()
  selectedSubject:string
  @Output()
  selectedSubjectChange:EventEmitter<string>=new EventEmitter();
  
  subjectBaseChange(e){
    this.selectedSubjectChange.emit(e)
  }

  //获取年级
  GetCourseList(){
    this.subjectBaseList = [];
    this.service.GetCourseList(this.getData).subscribe(res=>{
      this.selectedSubject = ""
      this.subjectBaseList = res.data;
    })
  }


  
}
