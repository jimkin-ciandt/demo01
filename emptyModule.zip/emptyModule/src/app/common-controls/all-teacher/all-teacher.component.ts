import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {CommonControlService} from '../common-control.service';


@Component({
  selector: 'app-all-teacher',
  templateUrl: './all-teacher.component.html',
  styleUrls: ['./all-teacher.component.css']
})
export class AllTeacherComponent implements OnInit {

  constructor(private service: CommonControlService) {
    this.disable = false;
  }

  teacherList: any[] = [];
  getTeacherData = {
    'schoolID': '',
    'pager': {
      'pager': false,
      'pageIndex': 0,
      'pageSize': 0,
    }
  };

  ngOnInit() {

  }

  _selectScholId = '';
  @Input()
  set selectScholId(selectScholId: any) {
    this._selectScholId = selectScholId;
    if(selectScholId === ''){
      this.disable = this.selectScholId === '';
      return;
    }
    this.disable = false;
    this.getTeacherList();
  }

  get selectScholId() {
    return this._selectScholId;
  }


  @Input()
  disable: boolean;
  @Input()
  isFirst: boolean = false;
  //以选择的教师id
  @Input()
  selectedTeacher: string;
  @Output()
  selectedTeacherChange: EventEmitter<string> = new EventEmitter();



  //学校改变选择改变事件
  teacherChanges(data) {
    this.selectedTeacherChange.emit(data);
  }

  //获取教师列表信息
  getTeacherList() {
    this.getTeacherData.schoolID = this.selectScholId;
    this.service.GetEmployeeDetail(this.getTeacherData).subscribe(res => {
      if (res) {
        this.teacherList = res.data;
        //this.selectedTeacher = '';
        // this.selectedTeacherChange.emit('');
      }
    });
  }
}
