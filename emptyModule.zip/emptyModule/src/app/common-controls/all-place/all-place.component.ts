import {Component, EventEmitter, Input, OnInit, Output, TemplateRef, ViewChild} from '@angular/core';
import {CommonControlService} from '../common-control.service';
import {NzFormatEmitEvent, NzModalRef, NzModalService, NzTreeComponent, NzTreeNode, NzTreeNodeOptions} from 'ng-zorro-antd';

@Component({
  selector: 'app-all-place',
  templateUrl: './all-place.component.html',
  styleUrls: ['./all-place.component.css']
})
export class AllPlaceComponent implements OnInit {


  constructor(private service: CommonControlService, private modal: NzModalService) {
  }

  ngOnInit() {
    this.getScopeList();//获取代理商权限范围
  }

  //树控件是否级联
  @Input()
  isCasper: boolean = false;
  //是否可见
  isVisble: boolean = true;
  //模态框实例
  modalRef: NzModalRef;

  //输入框点击事件
  choosePlace(tplTitle: TemplateRef<{}>, tplContent: TemplateRef<{}>) {
    this.modalRef = this.modal.create({
      nzTitle: tplTitle,
      nzContent: tplContent,
      nzMaskClosable: false,
      nzClosable: false,
      nzOnOk: () => {
        this.selectedChange();
      }
    });
  }

  //读取tree控件
  @ViewChild('placeTree') treeCtr: NzTreeComponent;
  /**
   * 获取省市区接口
   * */
    //省市区数据字段
  placeInfoList: NzTreeNodeOptions[] | NzTreeNode[];
  //省市区源数据
  placeSourceList: NzTreeNode[];
  //获取数据loading
  getDataLoading: boolean = false;

  //获取省市区接口
  getScopeList() {
    let treeList = JSON.parse(localStorage.getItem('allPlacesCache'));
    if (treeList) {
      this.getFilterPlaceInfo(treeList);
    }
    else {
      this.service.getAgentScope().subscribe(res => {
        if (res) {
          let filterData = (data: NzTreeNodeOptions[]) => {
            for (let i = 0; i < data.length; i++) {
              data[i].isLeaf = !(data[i].children && data[i].children.length);
              if (data[i].children && data[i].children.length) {
                filterData(data[i].children);
              }
            }
          };
          filterData(res['data']);
          localStorage.setItem('allPlacesCache', JSON.stringify(res['data']));
          this.getFilterPlaceInfo(res['data']);
        }
      }, error1 => {
      });
    }
  }

  //点击省市区展开
  openChildPlaceNode(event: NzFormatEmitEvent) {
    let treeList: NzTreeNodeOptions[] = JSON.parse(localStorage.getItem('allPlacesCache'));
    let filterNode = (node: NzTreeNodeOptions[]) => {
      for (let i = 0; i < node.length; i++) {
        if (event.node.key === node[i].key) {
          if (event.node.isChecked && !this.isCasper) {
            for (let j = 0; j < node[i].children.length; j++) {
              node[i].children[j].checked = true;
            }
          }
          else if (event.node.isChecked && this.isCasper) {
            for (let j = 0; j < node[i].children.length; j++) {
              node[i].children[j].checked = this.selectedIDs.indexOf(node[i].children[j].key) !== -1;
            }
          }
          event.node.addChildren(node[i].children);
          return;
        }
        else {
          filterNode(node[i].children);
        }
      }
    };
    if (event.node.isExpanded) {
      if (event.node.getChildren().length === 0) {
        filterNode(treeList);
      }
      else {
        for (let j = 0; j < event.node.children.length; j++) {
          event.node.children[j].isChecked = this.selectedIDs.indexOf(event.node.children[j].key) !== -1;
        }
      }
    }
  }

  //过滤列表
  getFilterPlaceInfo(dataList: NzTreeNodeOptions[]) {
    let list = [...dataList];
    for (let i = 0; i < list.length; i++) {
      list[i].children = [];
    }
    this.placeInfoList = list;
  }

  //已选择的省市区id
  @Input()
  selectedIDs: string[] = [];
  //选中省市区改变事件
  @Output()
  selectedIDsChange: EventEmitter<string[]> = new EventEmitter();
  //已选择的省市区文本
  @Input()
  selectedText: string = '';
  @Output()
  selectedTextChange: EventEmitter<string[]> = new EventEmitter();

  //选择改变
  selectedChange() {
    let nodes = this.treeCtr.getCheckedNodeList();
    let checkInfo = this.getCheckedKeys(nodes);
    this.selectedIDsChange.emit(checkInfo.keys);
    this.selectedTextChange.emit(checkInfo.titles);
    this.selectedText = checkInfo.titles.join(',');
  }

  //判断选中的节点是否有子级
  getChildNodesByParent(inputNode: NzTreeNode) {
    let treeList: NzTreeNodeOptions[] = JSON.parse(localStorage.getItem('allPlacesCache'));
    let filterNode = (node: NzTreeNodeOptions[]) => {
      for (let i = 0; i < node.length; i++) {
        if (inputNode.key === node[i].key) {
          inputNode.addChildren(node[i].children);
          return;
        }
        else {
          filterNode(node[i].children);
        }
      }
    };
    filterNode(treeList);
  }

  //获取已选择的节点id
  getCheckedKeys(inputNodes: NzTreeNode[]) {
    let checkedKeys = {
      keys: [],
      titles: []
    };
    for (let i = 0; i < inputNodes.length; i++) {
      if (inputNodes[i].getChildren().length === 0) {
        this.getChildNodesByParent(inputNodes[i]);
      }
    }
    let filterNode = (nodes: NzTreeNode[]) => {
      for (let i = 0; i < nodes.length; i++) {
        if (!nodes[i].children.length) {
          checkedKeys.keys.push(nodes[i].key);
          checkedKeys.titles.push(nodes[i].title);

        }
        if (nodes[i].children.length) {
          filterNode(nodes[i].children);
        }
      }
    };
    if (!this.isCasper) {
      filterNode(inputNodes);
    }
    else {
      for (let i = 0; i < inputNodes.length; i++) {
        checkedKeys.keys.push(inputNodes[i].key);
        checkedKeys.titles.push(inputNodes[i].title);
      }
    }
    return checkedKeys;
  }


}
