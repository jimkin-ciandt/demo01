import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SchoolClaaaSelectComponent } from './school-claaa-select.component';

describe('SchoolClaaaSelectComponent', () => {
  let component: SchoolClaaaSelectComponent;
  let fixture: ComponentFixture<SchoolClaaaSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SchoolClaaaSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SchoolClaaaSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
