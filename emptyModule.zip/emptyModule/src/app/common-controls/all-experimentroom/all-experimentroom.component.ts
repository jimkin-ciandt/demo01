import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService} from '../common-control.service';
@Component({
  selector: 'app-all-experimentroom',
  templateUrl: './all-experimentroom.component.html',
  styleUrls: ['./all-experimentroom.component.css']
})
export class AllExperimentroomComponent implements OnInit {

  constructor(private service: CommonControlService) {
    this.disable = false;
  }

  ngOnInit() {
  }
  _schoolID:string = '';
  // 传入的学校id
  @Input()
  set schoolID(schoolID:string){
    this._schoolID = schoolID;
    // id为空时，disable为true
    if(schoolID === ''){
      this.disable = schoolID === '';
      return;
    }
    // this.roomChanges(this.schoolID);
    this.getExperimentRoomList(this.schoolID);
    this.disable = false;
  }
  get schoolID(){
    return this._schoolID;
  }
  @Input()
  disable:boolean;
  // 已选择的教室
  @Input()
  selectedExperiroomID: string = '';
  // 教室改变发射事件
  @Output()
  selectedExperiroomIDChange: EventEmitter<string> = new EventEmitter();
  // 获取实验室根据学校
  experimentRoomList:any[] = [];
  getExperimentRoomList(id){
    this.service.getExperimentRoomBySchool(
      {
        schoolid:id
      }).subscribe(res=>{
        if(res){
          this.experimentRoomList = res['data'];
          this.selectedExperiroomID = '';

          // this.selectedExperiroomIDChange.emit('');
        }
    });
  }
  // 教室改变事件
  roomChanges(id) {
    this.selectedExperiroomIDChange.emit(id);
  }
}
