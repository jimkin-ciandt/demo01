import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllExperimentroomComponent } from './all-experimentroom.component';

describe('AllExperimentroomComponent', () => {
  let component: AllExperimentroomComponent;
  let fixture: ComponentFixture<AllExperimentroomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllExperimentroomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllExperimentroomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
