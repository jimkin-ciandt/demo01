import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService, schoolListInfo} from '../common-control.service';

@Component({
  selector: 'app-multiple-select-school',
  templateUrl: './multiple-select-school.component.html',
  styleUrls: ['./multiple-select-school.component.css']
})
export class MultipleSelectSchoolComponent implements OnInit {

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
  }

  //获取数据参数
  getData = {
    'countyids': []
  };
  //地区id
  _area_id: string[] = [];
  @Input()
  set area_id(ids: any[]) {
    this._area_id = ids;
    this.getData.countyids = ids;
    this.getSchoolList(this.getData);
  }

  get area_id() {
    return this._area_id;
  }

  //已选择的学校ID
  @Input()
  selectedSchool: any[];

  @Output()
  selectedSchoolChange: EventEmitter<any[]> = new EventEmitter();

  //学校改变选择改变事件
  schoolChanges(data) {
    this.selectedSchoolChange.emit(data);
  }

  //学校列表
  schoolListInfo: schoolListInfo[] = [];

  //获取学校列表信息
  getSchoolList(data) {
    this.service.GetSchoolInfoByCounty(data).subscribe(res => {
      if (res) {
        this.schoolListInfo = <schoolListInfo[]>res['data'];
      }
    });
  }
}
