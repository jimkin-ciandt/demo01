import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultipleSelectSchoolComponent } from './multiple-select-school.component';

describe('MultipleSelectSchoolComponent', () => {
  let component: MultipleSelectSchoolComponent;
  let fixture: ComponentFixture<MultipleSelectSchoolComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultipleSelectSchoolComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultipleSelectSchoolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
