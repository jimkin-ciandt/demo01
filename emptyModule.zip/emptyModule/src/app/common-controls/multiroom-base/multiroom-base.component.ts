import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService} from '../common-control.service';

@Component({
  selector: 'app-multiroom-base',
  templateUrl: './multiroom-base.component.html',
  styleUrls: ['./multiroom-base.component.css']
})
export class MultiroomBaseComponent implements OnInit {

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
    this.getMultiroomList();//获取多功能教室列表
  }

  //已选择的id
  @Input()
  selectedID: string = '';
  //事件发射
  @Output()
  selectedIDChange: EventEmitter<string> = new EventEmitter();
  //列表字段
  multiroomList: { id?: string, name?: string }[] = [];

  //获取列表字段
  getMultiroomList() {
    this.service.getMultiRoomBase().subscribe(res => {
      if (res) {
        this.multiroomList = res['data'];
      }
    });
  }

  //下拉框选择改变事件
  modelChange(id) {
    this.selectedIDChange.emit(id);
  }
}
