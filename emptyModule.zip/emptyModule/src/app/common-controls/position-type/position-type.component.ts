import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService} from '../common-control.service';

@Component({
  selector: 'app-position-type',
  templateUrl: './position-type.component.html',
  styleUrls: ['./position-type.component.css']
})
export class PositionTypeComponent implements OnInit {

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
    this.getPositionLevel();//获取职称列表
  }

  //当前选择的职称
  @Input()
  selectedPosition: string = '';
  //选择事件
  @Output()
  selectedPositionChange: EventEmitter<string> = new EventEmitter();

  //选择改变事件
  positionChanges(id) {
    this.selectedPositionChange.emit(id);
  }

  //职称列表字段
  positionLevel: {
    id?: string
    name?: string
  }[] = [];

  //获取职称列表
  getPositionLevel() {
    this.service.getEduLevelList({
      'parentcode': 'positionlevel'
    }).subscribe(res => {
      if (res) {
        this.positionLevel = res['data'];
      }
    });
  }
}
