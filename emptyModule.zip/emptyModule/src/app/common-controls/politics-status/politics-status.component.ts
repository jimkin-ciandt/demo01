import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CommonControlService} from '../common-control.service';

@Component({
  selector: 'app-politics-status',
  templateUrl: './politics-status.component.html',
  styleUrls: ['./politics-status.component.css']
})
export class PoliticsStatusComponent implements OnInit {

  constructor(private service: CommonControlService) {
  }

  ngOnInit() {
    this.getPoliticalList();//获取列表
  }
   //已选择项
  @Input()
  selectedPolitical:string='';
  //事件
  @Output()
  selectedPoliticalChange:EventEmitter<string>=new EventEmitter();
  //选择改变事件
  politicalChanges(id){
    this.selectedPoliticalChange.emit(id);
  }

  //政治面貌列表
  politicalList: {
    id?: string
    name?: string
  }[] = [];

  //获取政治面貌列表
  getPoliticalList() {
    this.service.getEduLevelList({
      'parentcode': 'Political'
    }).subscribe(res => {
      if (res) {
        this.politicalList = res['data'];
      }
    });
  }
}
