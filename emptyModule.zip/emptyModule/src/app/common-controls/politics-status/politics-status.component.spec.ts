import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PoliticsStatusComponent } from './politics-status.component';

describe('PoliticsStatusComponent', () => {
  let component: PoliticsStatusComponent;
  let fixture: ComponentFixture<PoliticsStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PoliticsStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PoliticsStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
