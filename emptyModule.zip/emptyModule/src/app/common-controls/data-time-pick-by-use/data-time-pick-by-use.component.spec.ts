import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataTimePickByUseComponent } from './data-time-pick-by-use.component';

describe('DataTimePickByUseComponent', () => {
  let component: DataTimePickByUseComponent;
  let fixture: ComponentFixture<DataTimePickByUseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataTimePickByUseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataTimePickByUseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
