import {Component, EventEmitter, Input, OnChanges, OnInit, Output, TemplateRef, ViewChild} from '@angular/core';
import {CommonControlService} from '../common-control.service';
import {NzModalService, NzTreeComponent, NzTreeNode, NzTreeNodeOptions} from 'ng-zorro-antd';

@Component({
  selector: 'app-place-selected',
  templateUrl: './place-selected.component.html',
  styleUrls: ['./place-selected.component.css']
})
export class PlaceSelectedComponent implements OnInit, OnChanges {

  constructor(private service: CommonControlService, private modal: NzModalService) {
  }

  ngOnInit() {
    this.getPlaceInfo();//获取省市区
  }

  ngOnChanges(): void {

  }

  //输入框点击事件
  choosePlace(tplTitle: TemplateRef<{}>, tplContent: TemplateRef<{}>) {

    this.modal.create({
      nzTitle: tplTitle,
      nzContent: tplContent,
      nzMaskClosable: false,
      nzClosable: false,
      nzOnOk: () => {
        this.selectedChange();
      }
    });
  }

  //读取tree控件
  @ViewChild('palceTree') treeCtr: NzTreeComponent;
  /**
   * 获取省市区接口
   * */
    //省市区数据字段
  placeInfoList: NzTreeNodeOptions[];
  //获取数据loading
  getDataLoading: boolean = false;

  //获取省市区接口
  getPlaceInfo() {
    this.service.getPlaceInfo().subscribe(res => {
      if (res) {
        this.placeInfoList = res['data'];
        let filterData = (data: NzTreeNodeOptions[]) => {
          for (let i = 0; i < data.length; i++) {
            data[i].isLeaf = !(data[i].children && data[i].children.length);
            if (data[i].children && data[i].children.length) {
              filterData(data[i].children);
            }
          }
        };
        filterData(this.placeInfoList);
      }
    }, err => {
    });
  }

  getScopeList() {
    this.service.getAgentScope().subscribe(res => {
      if (res) {
        this.placeInfoList = res['data'];
        let filterData = (data: NzTreeNodeOptions[]) => {
          for (let i = 0; i < data.length; i++) {
            data[i].isLeaf = !(data[i].children && data[i].children.length);
            if (data[i].children && data[i].children.length) {
              filterData(data[i].children);
            }
          }
        };
        filterData(this.placeInfoList);

      }
    }, error1 => {
    });
  }

  _selectedIDs: string[] = [];

  //已选择的省市区id
  @Input()
  set selectedIDs(ids: string[]) {
    this._selectedIDs = ids;
  }

  get selectedIDs() {
    return this._selectedIDs;
  }

  @Output()
  selectedIDsChange: EventEmitter<string[]> = new EventEmitter();
  @Input()
  selectedText: string = '';

  //选择改变
  selectedChange() {
    let nodes = this.treeCtr.getCheckedNodeList();
    let checkInfo = this.getCheckedKeys(nodes);
    this.selectedIDsChange.emit(checkInfo.keys);
    this.selectedText = checkInfo.titles.join(',');
  }

  //获取已选择的节点id
  getCheckedKeys(inputNodes: NzTreeNode[]) {
    let checkedKeys = {
      keys: [],
      titles: []
    };
    let filterNode = (nodes: NzTreeNode[]) => {
      for (let i = 0; i < nodes.length; i++) {
        if (!nodes[i].children.length) {
          checkedKeys.keys.push(nodes[i].key);
          checkedKeys.titles.push(nodes[i].title);

        }
        if (nodes[i].children.length) {
          filterNode(nodes[i].children);
        }
      }
    };
    filterNode(inputNodes);
    return checkedKeys;
  }

  //根据传进来的值勾选地区;
  checkNodesByKeys() {
     console.log(this.treeCtr.getCheckedNodeList());
  }
}
