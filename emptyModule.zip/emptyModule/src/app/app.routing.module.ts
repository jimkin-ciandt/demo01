import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {LoginGuard} from './app.service.service';

const AppRoutes: Routes = [
  //主框架路由
  {
    path: 'app', loadChildren: './main-frame/main-frame.module#MainFrameModule' ,canActivate:[LoginGuard],canLoad:[LoginGuard]
  },
  //登录页路由
  {
    path: 'login', loadChildren: './login-module/login-module.module#LoginModuleModule'
  },
  //未配备路由跳转默认页
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  },
  //默认页配置
  {path: '**', redirectTo: '/login', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(AppRoutes, {useHash: true})],
  exports: [RouterModule]
})
export class appRoutingModule {

}
