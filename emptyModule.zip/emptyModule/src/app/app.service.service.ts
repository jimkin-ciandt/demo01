import {Injectable} from '@angular/core';
import {HttpClient, HttpErrorResponse, HttpParams, HttpRequest} from '@angular/common/http';
import {map, catchError, tap} from 'rxjs/operators';
import {Observable, throwError} from 'rxjs';
import {NzMessageService, NzModalService, NzNotificationService} from 'ng-zorro-antd';
import {CanLoad, Route, Router} from '@angular/router';
import {CanActivate} from '@angular/router';
import {HttpHeaders} from '@angular/common/http';

/**
 * cookie操作服务
 * */
@Injectable(
  {providedIn: 'root'}
)
export class MyCookieSerivce {
  /**
   * 创建cookie
   * */
  setOrUpdateCookie(key: string, value: string, days: number) {
    let date = new Date();
    date.setTime(date.getTime() + 8 * 60 * 60 * 1000);
    let time = date.getTime() + days * 24 * 60 * 60 * 1000;
    date.setTime(time);
    document.cookie = `${key}=${value};expires=${date.toUTCString()}`;
  }

  /**
   * 获取cookie
   * */
  getCookie(name: string) {
    let allCookie = document.cookie;
    if (allCookie) {
      let cookieArray = allCookie.split(';');
      for (let i = 0; i < cookieArray.length; i++) {
        cookieArray[i] = cookieArray[i].trim();
        if (cookieArray[i].indexOf(name) === 0) {
          return cookieArray[i].substring(name.length + 1);
        }
      }
    }
    return '';
  }

  /**删除cookie*/
  deleteCookie(key: string) {
    let date = new Date();
    date.setTime(date.getTime() - 10000);
    document.cookie = `${key}=none;expires=${date.toUTCString()}`;
  }
}

/**
 * http接口访问公共服务
 * */
@Injectable({
  providedIn: 'root'
})
export class AppServiceService {
  constructor(private httpClient: HttpClient, private mess: NzMessageService, private router: Router, private cookie: MyCookieSerivce) {
  }

  //错误处理方法
  private errorHandler(err: HttpErrorResponse) {
    if (!navigator.onLine) {
      this.mess.error('网络异常,请检查网络连接!');
      return;
    }
    if (err.error instanceof ErrorEvent) {
      this.mess.error(err.message);
    }
    else {
      if (err.status) {
        switch (err.status) {
          case 200:
            this.mess.error(err.message);
            return throwError(err.message);
          case 401:
            this.router.navigateByUrl('/login');
            this.mess.error('暂无权限或服务已过期');
            return throwError('暂无权限或服务已过期!');
          case 403:
            this.router.navigateByUrl('/login');
            this.mess.error('服务已过期,请重新登录!');
            return throwError('服务已过期,请重新登录!');
          case 404:
            this.mess.error('服务器无此接口服务');
            return throwError('服务器无此接口服务!');
          case 500:
            this.mess.error('服务器内部错误！');
            return throwError('服务器内部错误!');
          case 502:
            this.mess.error('服务器异常,请稍后重试!');
            return throwError('服务器异常,请稍后重试!');
          default:
            this.mess.error('服务器访问异常');
            return throwError('服务器访问异常!');
        }
      }
      else {
        this.mess.error(err.message);
        return throwError(err);
      }
    }
  }

  //获取json文件
  getWebConfig(): Observable<any> {
    return this.httpClient.get('/webConfig.json');
  }
  //get纯方法
  getApiWithNoError(url){
    return this.httpClient.get(url);
  }
  //get方法
  getApi(params: any, url: string): Observable<any> {
    let cookie = this.cookie.getCookie('equipLogin');
    let header = new HttpHeaders({
      'Authorization': `Bearer ${cookie}`
    });
    let httpParam = new HttpParams();
    for (const item in params) {
     httpParam = httpParam.append(item, params[item]);
    }
    return this.httpClient.get(url, {
      params: httpParam,
      headers: header
    }).pipe(map((res) => {
      if (res['success']) {
        return res;
      }
      else {
        // this.mess.error(res['message']);
        throw new Error(res['message']);
      }
    }), catchError(err => this.errorHandler(err)));
  }

  getBtnRight(data): Observable<any> {
    return this.postApi('/api/SysUser/CheckMyRights', data);
  }
  
  //post方法 无错误提示
  postApi(url: string, params: any): Observable<any> {
    let cookie = this.cookie.getCookie('equipLogin');
    let header = new HttpHeaders({
      'Authorization': `${cookie}`
    });
    return this.httpClient.post(url, params, {
      headers: header
    }).pipe(
      map((res) => {
        if (res['success']) {
          return res;
        }
        else {
          throw new Error(res['message']);
        }
      }),
      catchError(err => this.errorHandler(err))
    );
  }

  //post方法
  postApiNoError(url: string, params: any): Observable<any> {
    let cookie = this.cookie.getCookie('equipLogin');
    let header = new HttpHeaders({
      'Authorization': `${cookie}`
    });
    return this.httpClient.post(url, params, {
      headers: header
    }).pipe(catchError(err => this.errorHandler(err)));
  }

  //上传文件方法
  uploadRequest(url: string, params: any) {
    const cookie = this.cookie.getCookie('equipLogin');
    const httpHeader = new HttpHeaders({
      'Authorization': `${cookie}`
    });
    const req = new HttpRequest('POST', url, params, {
      reportProgress: true,
      withCredentials: true,
      headers: httpHeader
    });
    return this.httpClient.request(req).pipe(
      catchError(err => this.errorHandler(err))
    );
  }

  //读取xml文件
  getWebSite() {
    let xmlhttp: any;
    xmlhttp = new XMLHttpRequest();
    xmlhttp.open('GET', '/webconfig.xml', false);
    xmlhttp.send();
    let xmlDom = xmlhttp.responseXML;
    return xmlDom.getElementsByTagName('website')[0].firstChild.nodeValue.toString();

  }
}

/**
 * 登录控制路由守卫
 * **/
@Injectable({
  providedIn: 'root'
})
export class LoginGuard implements CanActivate, CanLoad {
  constructor(private cookie: MyCookieSerivce, private mess: NzMessageService, private router: Router) {
  }

  canActivate(): boolean {
    if (!this.cookie.getCookie('equipLogin')) {
      this.mess.remove();
      this.mess.error('您尚未登录!');
      this.router.navigateByUrl('/login');
      return false;
    }
    return true;
  }

  canLoad(route: Route): Observable<boolean> | Promise<boolean> | boolean {
    return this.canActivate();
  }
}

@Injectable({
  providedIn: 'root'
})
export class importErrorHandle {
  constructor(private modal: NzModalService) {
  }

  //导入错误处理
  importError(errFileUrl: string) {
    this.modal.error({
      nzTitle: '导入出错!',
      nzContent: `<a href=${errFileUrl}>下载错误信息</a>`,
      nzOkText: '关闭',
      nzOkType: 'default'
    });
  }
}

@Injectable({
  providedIn: 'root'
})
export class messHandleService {
  constructor(private toa: NzMessageService, private notice: NzNotificationService) {
  }

  //成功
  success(content: string) {
    this.toa.success(content);
  }

  //错误提示
  error(title: string, content: string) {
    this.notice.error(title, content);
  }
}
