/**
 *宁波琢华软件科技有限公司
 *create by 兰志辉
 *-----页面描述----
 */
import {Injectable} from '@angular/core';
import {AppServiceService} from '../app.service.service';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
@Injectable()
export class LoginService {
  constructor(private globalService:AppServiceService,private http:HttpClient){}
  //登录接口
  loginIn(params:any):Observable<any>{
    return this.globalService.postApi('/login/login',params)
  }
  loginIns(params:any):Observable<any>{
    return this.http.post('/login/login',params)
  }
}
