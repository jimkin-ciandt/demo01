/**
 *宁波琢华软件科技有限公司
 *create by 兰志辉
 *-----登录页路由模块----
 */
import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {LoginComponentComponent} from './login-component/login-component.component';
const loginRoutes:Routes=[{
  path:'',component:LoginComponentComponent
}]
@NgModule({
   imports:[RouterModule.forChild(loginRoutes)],
  exports:[RouterModule]
})
export class LoginModuleRouting {

}
