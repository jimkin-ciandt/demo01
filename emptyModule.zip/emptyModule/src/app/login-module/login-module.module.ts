import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponentComponent } from './login-component/login-component.component';
import {LoginModuleRouting} from './login-module.routing';
import {NgZorroAntdModule} from 'ng-zorro-antd';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {LoginService} from './loginSerivice';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    LoginModuleRouting,
    NgZorroAntdModule,
    ReactiveFormsModule
  ],
  declarations: [LoginComponentComponent],
  providers:[LoginService]
})
export class LoginModuleModule { }
