import {AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {LoginService} from '../loginSerivice';
import {Subscription} from 'rxjs';
import {Router} from '@angular/router';
import {MyCookieSerivce} from '../../app.service.service';
import {FormControl} from '@angular/forms';
import {debounceTime, distinctUntilChanged} from 'rxjs/operators';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit, OnDestroy, AfterViewInit {

  constructor(private service: LoginService, private router: Router, private cookie: MyCookieSerivce) {
  }
  //登录输入框
  @ViewChild('loginName') loginName: ElementRef;
  //页面初始化完成后,登录名称输入框自动获取焦点
  ngAfterViewInit() {
    setTimeout(() => {
      (<HTMLElement>(this.loginName.nativeElement)).focus();
    }, 1);
  }

  ngOnInit() {
    this.loginInputChange();
  }
 //年月
  year=new Date().getFullYear();
  //接口请求列表
  httpRequestList: Subscription[] = [];

  //清除接口请求
  removeAllRequest() {
    for (let i = 0; i < this.httpRequestList.length; i++) {
      this.httpRequestList[i].unsubscribe();
    }
  }

  //记住用户名密码
  rememberPassword: boolean = false;
  //标记是否登录
  isLoading: boolean = false;
  //登录按钮名称
  btn_login: string = '登录';
  //用户名监控
  usernameCtr: FormControl = new FormControl();
  //密码监控
  passwordCtr: FormControl = new FormControl();

  //监控登录框改变
  loginInputChange() {
    this.usernameCtr.valueChanges.pipe(distinctUntilChanged(), debounceTime(100)).subscribe(res => {
      if (res) {
        this.usernameInvalid = false;
      }
    });
    this.passwordCtr.valueChanges.pipe(distinctUntilChanged(), debounceTime(100)).subscribe(res => {
      if (res) {
        this.passwordInvalid = false;
      }
    });
  }

  /**
   * 解决登录框浏览器自动填充用户名密码问题
   * */
    //登录框用户名是否为空
  usernameInvalid: boolean = false;
  //密码框是否为空
  passwordInvalid: boolean = false;

  //登录系统
  login() {
    /**
     * 没有用双向数据绑定是因为解决浏览器自动填充账号密码，主要是360
     * */
    let username = (<HTMLInputElement>document.getElementById('login_name')).value;
    let password = (<HTMLInputElement>document.getElementById('login_password')).value;
    /**
     * 如果检测到用户名密码,不允许登录,同时标红登录输入框
     * */
    if (!username || !password) {
      this.usernameInvalid = Boolean(!username);
      this.passwordInvalid = Boolean(!password);
      return;
    }

    this.isLoading = true;
    this.btn_login = '登录中...';
    let request = this.service.loginIn({
      username: username,
      password: password
    }).subscribe(res => {
      //清空菜单缓存
      localStorage.clear();
      sessionStorage.clear();
      if (res) {
        this.cookie.setOrUpdateCookie('equipLogin', res['data'], 0.5);
        this.router.navigateByUrl('/app/default/defaultPage');
      }
      else {
        this.isLoading = false;
        this.btn_login = '登录';
      }
    }, err => {

      this.isLoading = false;
      this.btn_login = '登录';
    });
    this.httpRequestList.push(request);
  }

  ngOnDestroy(): void {
    this.removeAllRequest();
  }
}
