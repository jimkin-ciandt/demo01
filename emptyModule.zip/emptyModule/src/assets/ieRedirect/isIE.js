function IEVersion() {
  var userAgent = navigator.userAgent;
  var isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1;
  var isEdge = userAgent.indexOf("Edge") > -1 && !isIE;
  var isIE11 = userAgent.indexOf("Trident") > -1 && userAgent.indexOf("rv:11.0") > -1;
  if (isIE) {
    var reIE = new RegExp("MSIE (\\d+\\.\\d+);");
    reIE.test(userAgent);
    var fIEVersion = parseFloat(RegExp["$1"]);
    if (fIEVersion == 7) {
      return 7
    } else {
      if (fIEVersion == 8) {
        return 8
      } else {
        if (fIEVersion == 9) {
          return 9
        } else {
          if (fIEVersion == 10) {
            return 10
          } else {
            return 6
          }
        }
      }
    }
  } else {
    if (isEdge) {
      return 12
    } else {
      if (isIE11) {
        return 11
      } else {
        return -1
      }
    }
  }
}

function redirectByIEVersion() {
  var version = IEVersion();
  if (version < 11 && version !== -1) {
    location.replace("/assets/ieRedirect/browzerDownload.html")
  }
}

redirectByIEVersion();
