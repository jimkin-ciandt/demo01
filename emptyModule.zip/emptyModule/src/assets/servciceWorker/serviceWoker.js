/**
 *宁波琢华软件科技有限公司
 *create by 兰志辉
 *-----页面描述----
 */
if('serviceWorker' in navigator){
  window.onload=function () {
    navigator.serviceWorker.register('/ngsw-worker.js')
      .then(function(registartion){
      })
  }
}
